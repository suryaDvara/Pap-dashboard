package Lendingpom;

import org.openqa.selenium.WebDriver;

import Pappom.Papaddbovine;
import Pappom.Papass;
import Pappom.Papedit;
import Pappom.Papfarmerquestion;
import Pappom.Papfeeddetails;
import Pappom.Paplac;
import Pappom.Paplocalfeed;
import Pappom.Paplogin;
import Pappom.Papphotoscreen;
import Pappom.Pappreventivecare;
import Pappom.Papusersetting;

public class Lendingmanager {
	public WebDriver driver;
    
    private Lendinglogin phno;
    private Lendingusersetting usersetting;
    private Papaddbovine addbovine;
    private Paplac lactation;
    private Papfeeddetails feeddetails;
    private Paplocalfeed localfeed;
    private Pappreventivecare preventivecare;
    private Papfarmerquestion farmerques;
    private Papphotoscreen photoscreen;
    private Papedit edit;
    private Papass assessment;
    public Lendingmanager(WebDriver driver) {
    	this.driver=driver;
    }
    public Lendinglogin get_Instance_phno() {
    	if (phno==null) {
        phno=new Lendinglogin(driver);     
    	}
    return phno;
    }
    public Lendingusersetting get_Instance_usersetting() {
    	if (usersetting==null) {
        usersetting=new Lendingusersetting(driver);     
    	}
    return usersetting;
    }
    
    public Papaddbovine get_Instance_addbovine() {
    	if (addbovine==null) {
        addbovine=new Papaddbovine(driver);     
    	}
    return addbovine;
    }
    public Paplac get_Instance_lactation() {
    	if (lactation==null) {
    		lactation=new Paplac(driver);     
    	}
    return lactation;
    }
    public Papfeeddetails get_Instance_feeddetails() {
    	if (feeddetails==null) {
    		feeddetails=new Papfeeddetails(driver);     
    	}
    return feeddetails;
    }
    
    public Paplocalfeed get_Instance_localfeed() {
    	if (localfeed==null) {
    		localfeed=new Paplocalfeed(driver);     
    	}
    return localfeed;
    }
    
    public Pappreventivecare get_Instance_preventivecare() {
    	if (preventivecare==null) {
    		preventivecare=new Pappreventivecare(driver);     
    	}
    return preventivecare;
    }
    public  Papfarmerquestion get_Instance_farmerques() {
    	if (farmerques==null) {
    		farmerques=new  Papfarmerquestion(driver);     
    	}
    return farmerques;
    }
    public  Papphotoscreen get_Instance_photoscreen() {
    	if (photoscreen==null) {
    		photoscreen=new  Papphotoscreen(driver);     
    	}
    return photoscreen;
    }
    public Papedit get_Instance_edit() {
    	if (edit==null) {
    		edit=new  Papedit(driver);     
    	}
    return edit;
    }
    public Papass get_Instance_assessment() {
    	if (assessment==null) {
    		assessment=new  Papass(driver);     
    	}
    return assessment;
    }
}


