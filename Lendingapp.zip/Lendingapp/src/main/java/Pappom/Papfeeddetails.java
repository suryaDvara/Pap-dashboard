package Pappom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Papfeeddetails {
	public WebDriver driver;
	public Papfeeddetails(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);

    }

	//Feed details
	@FindBy(id="com.DvaraEDairy.fposasdev:id/id_19")private WebElement Greenfodder;
	public WebElement getGreenfodder() {
		return Greenfodder;
	}
	public void setGreenfodder(WebElement greenfodder) {
		Greenfodder = greenfodder;
	}
	public WebElement getDryfodder() {
		return Dryfodder;
	}
	public void setDryfodder(WebElement dryfodder) {
		Dryfodder = dryfodder;
	}
	public WebElement getConcentratedfodder() {
		return concentratedfodder;
	}
	public void setConcentratedfodder(WebElement concentratedfodder) {
		this.concentratedfodder = concentratedfodder;
	}
	public WebElement getNext4() {
		return Next4;
	}
	public void setNext4(WebElement next4) {
		Next4 = next4;
	}

	@FindBy(id="com.DvaraEDairy.fposasdev:id/id_21")private WebElement Dryfodder;
	@FindBy(id="com.DvaraEDairy.fposasdev:id/id_58")private WebElement concentratedfodder;
	@FindBy(id="com.DvaraEDairy.fposasdev:id/next11")private WebElement Next4;
	
	
	
	
}
