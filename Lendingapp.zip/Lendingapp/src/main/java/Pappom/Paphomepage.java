package Pappom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Paphomepage {
	
	public WebDriver driver;
	public Paphomepage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);

    }	

	@FindBy(xpath="//android.widget.ImageView[@content-desc=\"More options\"]")private WebElement Usersetting1;
		
		public WebDriver getDriver() {
			return driver;
		}

	public WebElement getUsersetting1() {
		return Usersetting1;
	}
	public void setUsersetting1(WebElement Usersetting1) {
		this.Usersetting1 =Usersetting1;
	}
	public WebElement getusedit() {
		return usedit;
	}
	public void setusedit(WebElement usedit) {
		this.usedit = usedit;
	}
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView")private WebElement up;	
	public WebElement getup() {
		return up;
	}

	public void setup(WebElement up) {
		this.up = up;
	}

	@FindBy(id="com.DvaraEDairy.fposasdev:id/EditDetails")private WebElement usedit;
	@FindBy(id="com.DvaraEDairy.fposasdev:id/name")private WebElement Username;


	public WebElement getUsername() {
		return Username;
	}

	public void setUsername(WebElement username) {
		Username = username;
	} 
	
	
	@FindBy(id="com.DvaraEDairy.fposasdev:id/Organization")private WebElement orgs;
	
	public WebElement getOrgs() {
		return orgs;
	}

	public void setOrgs(WebElement orgs) {
		this.orgs = orgs;
	}

	@FindBy(id="com.DvaraEDairy.fposasdev:id/UpdateDetails")private WebElement updetails;



	public WebElement getUpdetails() {
		return updetails;
	}

	public void setUpdetails(WebElement updetails) {
		this.updetails = updetails;
	}
	
	//setlanguagetamil
	@FindBy(xpath="//android.widget.ImageView[@content-desc=\"More options\"]")private WebElement us1;
	public WebElement getus1() {
		return us1;
	}

	public void setus1(WebElement us1) {
		this.us1 = us1;
	}

	public WebElement gettamil() {
		return tamil;
	}

	public void setTamil(WebElement tamil) {
		this.tamil = tamil;
	}

	public WebElement gettr1() {
		return tr1;
	}

	public void settr1(WebElement tr1) {
		this.tr1 = tr1;
	}
	public WebElement gettok2() {
		return tok2;
	}

	public void setTr1(WebElement tok2) {
		this.tok2 = tok2;
	}
	
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[3]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView")private WebElement tamil;
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.RadioGroup/android.widget.RadioButton[6]")private WebElement tr1;
	@FindBy(id="com.DvaraEDairy.fposasdev:id/dialog_OK")private WebElement tok2;
	
	//lang2guja
  @FindBy(xpath="//android.widget.ImageView[@content-desc=\"More options\"]")private WebElement us2;
  public WebElement getus2() {
	return us2;
}

public void setus2(WebElement us2) {
	this.us2 = us2;
}

public WebElement getgujarathi() {
	return gujarathi;
}

public void setgujarathi(WebElement gujarathi) {
	this.gujarathi = gujarathi;
}

public WebElement getg1() {
	return g1;
}

public void setg1(WebElement g1) {
	this.g1 = g1;
}

public WebElement getgok2() {
	return gok2;
}

public void setgok2(WebElement gok2) {
	this.gok2 = gok2;
}

  @FindBy(xpath="/hierarchy/android.widget.FrameLayout/android."
		+ "widget.FrameLayout/android.widget.ListView/android.widget."
		+ "LinearLayout[3]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView")private WebElement gujarathi;
  @FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.RadioGroup/android.widget.RadioButton[2]")private WebElement g1;
  @FindBy(id="com.DvaraEDairy.fposasdev:id/dialog_OK")private WebElement gok2;
	

//Hindi
  
 	@FindBy(xpath="//android.widget.ImageView[@content-desc=\"More options\"]")private WebElement us3;
	public WebElement getus3() {
		return us3;
	}

	public void setus3(WebElement us3) {
		this.us3 = us3;
	}

	public WebElement gethindi() {
		return hindi;
	}

	public void sethindi(WebElement hindi) {
		this.hindi = hindi;
	}

	public WebElement geth1() {
		return h1;
	}

	public void seth1(WebElement h1) {
		this.h1 = h1;
	}

	public WebElement gethok2() {
		return hok2;
	}

	public void sethok2(WebElement hok2) {
		this.hok2 = hok2;
	}

	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[3]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView")private WebElement hindi;
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.RadioGroup/android.widget.RadioButton[4]")private WebElement h1;
	@FindBy(id="com.DvaraEDairy.fposasdev:id/dialog_OK")private WebElement hok2;
	
	//kanada
	    @FindBy(xpath="//android.widget.ImageView[@content-desc=\"More options\"]")private WebElement us4;
		
		public WebElement getus4() {
			return us4;
		}

		public void setus4(WebElement us4) {
			this.us4 = us4;
		}

		public WebElement getkannada() {
			return kannada;
		}

		public void setKannada(WebElement kannada) {
			this.kannada = kannada;
		}

		public WebElement getK1() {
			return k1;
		}

		public void setK1(WebElement k1) {
			this.k1 = k1;
		}

		public WebElement getKok2() {
			return kok2;
		}

		public void setKok2(WebElement kok2) {
			this.kok2 = kok2;
		}

		@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[3]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView")private WebElement kannada;
		
		@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.RadioGroup/android.widget.RadioButton[5]")private WebElement k1;
		
		@FindBy(id="com.DvaraEDairy.fposasdev:id/dialog_OK")private WebElement kok2;
				

		//Marathi
		@FindBy(xpath="//android.widget.ImageView[@content-desc=\"More options\"]")private WebElement us5;
		
		public WebElement getus5() {
			return us5;
		}

		public void setus5(WebElement us5) {
			this.us5 = us5;
		}

		public WebElement getMarathi() {
			return Marathi;
		}

		public void setMarathi(WebElement Marathi) {
			Marathi = Marathi;
		}

		public WebElement getm1() {
			return m1;
		}

		public void setm1(WebElement m1) {
			this.m1 = m1;
		}

		public WebElement getmok2() {
			return mok2;
		}

		public void setmok2(WebElement mok2) {
			this.mok2 = mok2;
		}

		@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[3]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView")private WebElement Marathi;
	
		@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.RadioGroup/android.widget.RadioButton[6]")private WebElement m1;
		
		@FindBy(id="com.DvaraEDairy.fposasdev:id/dialog_OK")private WebElement mok2;
		
		//Telugu
		@FindBy(xpath="//android.widget.ImageView[@content-desc=\"More options\"]")private WebElement us6;
		
		public WebElement getUs6() {
			return us6;
		}

		public void setUs6(WebElement us6) {
			this.us6 = us6;
		}

		public WebElement gettelugu() {
			return Telugu;
		}

		public void settelugu(WebElement telugu) {
			telugu = telugu;
		}

		public WebElement gettelugu1() {
			return telugu1;
		}

		public void setTelugu1(WebElement telugu1) {
			this.telugu1 = telugu1;
		}

		public WebElement gettelok2() {
			return telok2;
		}

		public void settelok2(WebElement telok2) {
			this.telok2 = telok2;
		}

		@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[3]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView")private WebElement Telugu;
		
		@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.RadioGroup/android.widget.RadioButton[7]")private WebElement telugu1;
		
		@FindBy(id="com.DvaraEDairy.fposasdev:id/dialog_OK")private WebElement telok2;
		
	//english
	
	@FindBy(xpath="//android.widget.ImageView[@content-desc=\"More options\"]")private WebElement us7;
	public WebElement getus7() {
		return us7;
	}

	public void setus7(WebElement us7) {
		this.us7 = us7;
	}

	public WebElement getEnglish() {
		return English;
	}

	public void setEnglish(WebElement English) {
		English = English;
	}

	
	public WebElement getEngok2() {
		return Engok2;
	}

	public void setEngok2(WebElement Engok2) {
		this.Engok2 = Engok2;
	}

	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[3]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView")private WebElement English;
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.RadioGroup/android.widget.RadioButton[1]")private WebElement Eok2;
	public WebElement getEok2() {
		return Eok2;
	}

	public void setEok2(WebElement eok2) {
		Eok2 = eok2;
	}

	@FindBy(id="com.DvaraEDairy.fposasdev:id/dialog_OK")private WebElement Engok2;

	//Refresh
	@FindBy(xpath="//android.widget.ImageView[@content-desc=\"More options\"]")private WebElement us8;
	public WebElement getus8() {
		return us8;
	}

	public void setus8(WebElement us8) {
		this.us8 = us8;
	}

	public WebElement getrefresh() {
		return refresh;
	}

	public void setrefresh(WebElement refresh) {
		this.refresh = refresh;
	}

	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[4]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView")private WebElement refresh;
	
	//customer support
	@FindBy(xpath="//android.widget.ImageView[@content-desc=\"More options\"]")private WebElement cs;
	public WebElement getcs() {
		return cs;
	}

	public void setcs(WebElement cs) {
		this.cs = cs;
	}

	public WebElement getcs1() {
		return cs1;
	}

	public void setcs1(WebElement cs1) {
		this.cs1 = cs1;
	}

	public WebElement getclose() {
		return close;
	}

	public void setclose(WebElement close) {
		this.close = close;
	}

	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[5]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView")private WebElement cs1;
	//driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[5]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView")).click();
	@FindBy(id="com.DvaraEDairy.fposasdev:id/closeicon")private WebElement close;

	//version
	@FindBy(xpath="//android.widget.ImageView[@content-desc=\"More options\"]")private WebElement V1;
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[7]/android.widget.LinearLayout")private WebElement Version;

	public WebElement getVersion() {
		return Version;
	}

	public void setVersion(WebElement version) {
		version = version;
	}

	public WebElement getLogoutbt() {
		return Logoutbt;
	}

	public void setLogoutbt(WebElement Logoutbt) {
		Logoutbt = Logoutbt;
	}

	//logout
	
	@FindBy(xpath="//android.widget.ImageView[@content-desc=\"More options\"]")private WebElement Logout;
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[6]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView")private WebElement Logoutbt;
	
	@FindBy(id="android:id/button1")private WebElement button;
	public WebElement getv1() {
		return V1;
	}

	public WebElement getLogout() {
		return Logout;
	}

	public void setLogout(WebElement Logout) {
		Logout = Logout;
	}

	public WebElement getbutton() {
		return button;
	}

	public void setButton(WebElement button) {
		this.button = button;
	}

	public void setV1(WebElement v1) {
		v1 = v1;
	}
	
	
	
}
