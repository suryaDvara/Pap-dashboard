package Pappom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Papass {
	public WebDriver driver;
	public Papass(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
    }	
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.LinearLayout[2]/android.widget.FrameLayout/android.widget.RelativeLayout")private WebElement assclick;
public WebElement getAssclick() {
		return assclick;
	}
	public void setAssclick(WebElement assclick) {
		this.assclick = assclick;
	}
	public WebElement getAssfarmerno() {
		return assfarmerno;
	}
	public void setAssfarmerno(WebElement assfarmerno) {
		this.assfarmerno = assfarmerno;
	}
	public WebElement getFarmerassclick() {
		return farmerassclick;
	}
	public void setFarmerassclick(WebElement farmerassclick) {
		this.farmerassclick = farmerassclick;
	}
	public WebElement getPfarmerass1() {
		return pfarmerass1;
	}
	public void setPfarmerass1(WebElement pfarmerass1) {
		this.pfarmerass1 = pfarmerass1;
	}
	public WebElement getYes() {
		return yes;
	}
	public void setYes(WebElement yes) {
		this.yes = yes;
	}
	public WebElement getImplementyes() {
		return implementyes;
	}
	public void setImplementyes(WebElement implementyes) {
		this.implementyes = implementyes;
	}
	public WebElement getDewyes() {
		return dewyes;
	}
	public void setDewyes(WebElement dewyes) {
		this.dewyes = dewyes;
	}
	public WebElement getVaccyes() {
		return vaccyes;
	}
	public void setVaccyes(WebElement vaccyes) {
		this.vaccyes = vaccyes;
	}
	public WebElement getMmyes() {
		return mmyes;
	}
	public void setMmyes(WebElement mmyes) {
		this.mmyes = mmyes;
	}
	public WebElement getFeedcost() {
		return feedcost;
	}
	public void setFeedcost(WebElement feedcost) {
		this.feedcost = feedcost;
	}
	public WebElement getMilkprice() {
		return milkprice;
	}
	public void setMilkprice(WebElement milkprice) {
		this.milkprice = milkprice;
	}
	public WebElement getAmount() {
		return amount;
	}
	public void setAmount(WebElement amount) {
		this.amount = amount;
	}
	public WebElement getLiter() {
		return liter;
	}
	public void setLiter(WebElement liter) {
		this.liter = liter;
	}
	public WebElement getAssnext() {
		return assnext;
	}
	public void setAssnext(WebElement assnext) {
		this.assnext = assnext;
	}
@FindBy(id="com.DvaraEDairy.fposasdev:id/et_assessment_mobile")private WebElement assfarmerno;//6785949355
@FindBy(id="com.DvaraEDairy.fposasdev:id/tvFarmerMobile")private WebElement farmerassclick;
@FindBy(id="com.DvaraEDairy.fposasdev:id/rl_root")private WebElement pfarmerass1;
@FindBy(id="com.DvaraEDairy.fposasdev:id/rb_received_yes")private WebElement yes;
@FindBy(id="com.DvaraEDairy.fposasdev:id/rb_implemented_yes")private WebElement implementyes;
@FindBy(id="com.DvaraEDairy.fposasdev:id/rb_deworming_yes")private WebElement dewyes;
@FindBy(id="com.DvaraEDairy.fposasdev:id/rb_vaccination_yes")private WebElement vaccyes;
@FindBy(id="com.DvaraEDairy.fposasdev:id/rb_mineral_yes")private WebElement mmyes;
@FindBy(id="com.DvaraEDairy.fposasdev:id/cb_decrease_feedcost")private WebElement feedcost;
@FindBy(id="com.DvaraEDairy.fposasdev:id/cb_increase_milk")private WebElement milkprice;
@FindBy(id="com.DvaraEDairy.fposasdev:id/et_feed_cost")private WebElement amount;//33

@FindBy(id="com.DvaraEDairy.fposasdev:id/et_increase")private WebElement liter;//inc in liter
@FindBy(id="com.DvaraEDairy.fposasdev:id/btn_impact_next")private WebElement assnext;
//Bovine
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[1]/android.widget.TextView")private WebElement btypec1;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[3]")private WebElement selecttype;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[2]/android.widget.TextView")private WebElement Buffalotype1;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[3]")private WebElement btypeselect;
@FindBy(id="com.DvaraEDairy.fposasdev:id/id_42")private WebElement petname;
@FindBy(id="com.DvaraEDairy.fposasdev:id/id_48")private WebElement Lastcalving;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[3]/android.widget.TextView")private WebElement pregselect;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[3]")private WebElement pregstatus;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[4]/android.widget.TextView")private WebElement assmilklingstatus;

@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[3]")private WebElement assmilking;
@FindBy(id="com.DvaraEDairy.fposasdev:id/id_47")private WebElement Lactation;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[3]/android.widget.TextView")private WebElement onboardingselect;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[3]")private WebElement onboardtype;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[4]/android.widget.TextView")private WebElement assesstype;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[3]")private WebElement assessselect;
@FindBy(id="com.DvaraEDairy.fposasdev:id/next_1")private WebElement asnext;
//lactationdetails
@FindBy(id="com.DvaraEDairy.fposasdev:id/id_53")private WebElement peakmilkyield;
public WebDriver getDriver() {
	return driver;
}
public void setDriver(WebDriver driver) {
	this.driver = driver;
}
public WebElement getBtypec1() {
	return btypec1;
}
public void setBtypec1(WebElement btypec1) {
	this.btypec1 = btypec1;
}
public WebElement getSelecttype() {
	return selecttype;
}
public void setSelecttype(WebElement selecttype) {
	this.selecttype = selecttype;
}
public WebElement getBuffalotype1() {
	return Buffalotype1;
}
public void setBuffalotype1(WebElement buffalotype1) {
	Buffalotype1 = buffalotype1;
}
public WebElement getBtypeselect() {
	return btypeselect;
}
public void setBtypeselect(WebElement btypeselect) {
	this.btypeselect = btypeselect;
}
public WebElement getPetname() {
	return petname;
}
public void setPetname(WebElement petname) {
	this.petname = petname;
}
public WebElement getLastcalving() {
	return Lastcalving;
}
public void setLastcalving(WebElement lastcalving) {
	Lastcalving = lastcalving;
}
public WebElement getPregselect() {
	return pregselect;
}
public void setPregselect(WebElement pregselect) {
	this.pregselect = pregselect;
}
public WebElement getPregstatus() {
	return pregstatus;
}
public void setPregstatus(WebElement pregstatus) {
	this.pregstatus = pregstatus;
}
public WebElement getAssmilklingstatus() {
	return assmilklingstatus;
}
public void setAssmilklingstatus(WebElement assmilklingstatus) {
	this.assmilklingstatus = assmilklingstatus;
}
public WebElement getAssmilking() {
	return assmilking;
}
public void setAssmilking(WebElement assmilking) {
	this.assmilking = assmilking;
}
public WebElement getLactation() {
	return Lactation;
}
public void setLactation(WebElement lactation) {
	Lactation = lactation;
}
public WebElement getOnboardingselect() {
	return onboardingselect;
}
public void setOnboardingselect(WebElement onboardingselect) {
	this.onboardingselect = onboardingselect;
}
public WebElement getOnboardtype() {
	return onboardtype;
}
public void setOnboardtype(WebElement onboardtype) {
	this.onboardtype = onboardtype;
}
public WebElement getAssesstype() {
	return assesstype;
}
public void setAssesstype(WebElement assesstype) {
	this.assesstype = assesstype;
}
public WebElement getAssessselect() {
	return assessselect;
}
public void setAssessselect(WebElement assessselect) {
	this.assessselect = assessselect;
}
public WebElement getAsnext() {
	return asnext;
}
public void setAsnext(WebElement asnext) {
	this.asnext = asnext;
}
public WebElement getPeakmilkyield() {
	return peakmilkyield;
}
public void setPeakmilkyield(WebElement peakmilkyield) {
	this.peakmilkyield = peakmilkyield;
}
public WebElement getLacnext() {
	return lacnext;
}
public void setLacnext(WebElement lacnext) {
	this.lacnext = lacnext;
}
public WebElement getBdpregtype() {
	return bdpregtype;
}
public void setBdpregtype(WebElement bdpregtype) {
	this.bdpregtype = bdpregtype;
}
public WebElement getBdselect() {
	return bdselect;
}
public void setBdselect(WebElement bdselect) {
	this.bdselect = bdselect;
}
public WebElement getDss() {
	return dss;
}
public void setDss(WebElement dss) {
	this.dss = dss;
}
public WebElement getNofservice() {
	return nofservice;
}
public void setNofservice(WebElement nofservice) {
	this.nofservice = nofservice;
}
public WebElement getSelectservice() {
	return selectservice;
}
public void setSelectservice(WebElement selectservice) {
	this.selectservice = selectservice;
}
public WebElement getUptype() {
	return uptype;
}
public void setUptype(WebElement uptype) {
	this.uptype = uptype;
}
public WebElement getUpselect() {
	return upselect;
}
public void setUpselect(WebElement upselect) {
	this.upselect = upselect;
}
public WebElement getUttype() {
	return uttype;
}
public void setUttype(WebElement uttype) {
	this.uttype = uttype;
}
public WebElement getUtselect() {
	return utselect;
}
public void setUtselect(WebElement utselect) {
	this.utselect = utselect;
}
public WebElement getBdnext() {
	return bdnext;
}
public void setBdnext(WebElement bdnext) {
	this.bdnext = bdnext;
}
public WebElement getGf() {
	return gf;
}
public void setGf(WebElement gf) {
	this.gf = gf;
}
public WebElement getDf() {
	return df;
}
public void setDf(WebElement df) {
	this.df = df;
}
public WebElement getCf() {
	return cf;
}
public void setCf(WebElement cf) {
	this.cf = cf;
}
public WebElement getFdsnext() {
	return fdsnext;
}
public void setFdsnext(WebElement fdsnext) {
	this.fdsnext = fdsnext;
}
public WebElement getPdcstatus() {
	return Pdcstatus;
}
public void setPdcstatus(WebElement pdcstatus) {
	Pdcstatus = pdcstatus;
}
public WebElement getDdyes() {
	return ddyes;
}
public void setDdyes(WebElement ddyes) {
	this.ddyes = ddyes;
}
public WebElement getVstatus() {
	return vstatus;
}
public void setVstatus(WebElement vstatus) {
	this.vstatus = vstatus;
}
public WebElement getVyes() {
	return vyes;
}
public void setVyes(WebElement vyes) {
	this.vyes = vyes;
}
public WebElement getVexpense() {
	return vexpense;
}
public void setVexpense(WebElement vexpense) {
	this.vexpense = vexpense;
}
public WebElement getMajordisease() {
	return majordisease;
}
public void setMajordisease(WebElement majordisease) {
	this.majordisease = majordisease;
}
public WebElement getPcnext() {
	return pcnext;
}
public void setPcnext(WebElement pcnext) {
	this.pcnext = pcnext;
}
public WebElement getFarmerquestion() {
	return farmerquestion;
}
public void setFarmerquestion(WebElement farmerquestion) {
	this.farmerquestion = farmerquestion;
}
public WebElement getFarmerques() {
	return farmerques;
}
public void setFarmerques(WebElement farmerques) {
	this.farmerques = farmerques;
}
public WebElement getFullsideview() {
	return fullsideview;
}
public void setFullsideview(WebElement fullsideview) {
	this.fullsideview = fullsideview;
}
public WebElement getAsscam1() {
	return asscam1;
}
public void setAsscam1(WebElement asscam1) {
	this.asscam1 = asscam1;
}
public WebElement getAsscrop1() {
	return asscrop1;
}
public void setAsscrop1(WebElement asscrop1) {
	this.asscrop1 = asscrop1;
}
public WebElement getAssmuzzle() {
	return assmuzzle;
}
public void setAssmuzzle(WebElement assmuzzle) {
	this.assmuzzle = assmuzzle;
}
public WebElement getAsscontinue() {
	return asscontinue;
}
public void setAsscontinue(WebElement asscontinue) {
	this.asscontinue = asscontinue;
}
public WebElement getAssauto() {
	return assauto;
}
public void setAssauto(WebElement assauto) {
	this.assauto = assauto;
}
public WebElement getLeftside() {
	return leftside;
}
public void setLeftside(WebElement leftside) {
	this.leftside = leftside;
}
public WebElement getAsscam2() {
	return asscam2;
}
public void setAsscam2(WebElement asscam2) {
	this.asscam2 = asscam2;
}
public WebElement getAsscrop2() {
	return asscrop2;
}
public void setAsscrop2(WebElement asscrop2) {
	this.asscrop2 = asscrop2;
}
public WebElement getLsudder() {
	return Lsudder;
}
public void setLsudder(WebElement lsudder) {
	Lsudder = lsudder;
}
public WebElement getAsscam3() {
	return asscam3;
}
public void setAsscam3(WebElement asscam3) {
	this.asscam3 = asscam3;
}
public WebElement getAsscrop3() {
	return asscrop3;
}
public void setAsscrop3(WebElement asscrop3) {
	this.asscrop3 = asscrop3;
}
public WebElement getBsideview() {
	return bsideview;
}
public void setBsideview(WebElement bsideview) {
	this.bsideview = bsideview;
}
public WebElement getAsscam4() {
	return asscam4;
}
public void setAsscam4(WebElement asscam4) {
	this.asscam4 = asscam4;
}
public WebElement getAsscrop4() {
	return asscrop4;
}
public void setAsscrop4(WebElement asscrop4) {
	this.asscrop4 = asscrop4;
}
public WebElement getRsidetail() {
	return rsidetail;
}
public void setRsidetail(WebElement rsidetail) {
	this.rsidetail = rsidetail;
}
public WebElement getAsscam5() {
	return asscam5;
}
public void setAsscam5(WebElement asscam5) {
	this.asscam5 = asscam5;
}
public WebElement getAsscrop5() {
	return asscrop5;
}
public void setAsscrop5(WebElement asscrop5) {
	this.asscrop5 = asscrop5;
}
public WebElement getRightsideu() {
	return rightsideu;
}
public void setRightsideu(WebElement rightsideu) {
	this.rightsideu = rightsideu;
}
public WebElement getAsscam6() {
	return asscam6;
}
public void setAsscam6(WebElement asscam6) {
	this.asscam6 = asscam6;
}
public WebElement getAsscrop6() {
	return asscrop6;
}
public void setAsscrop6(WebElement asscrop6) {
	this.asscrop6 = asscrop6;
}
public WebElement getAbnor() {
	return abnor;
}
public void setAbnor(WebElement abnor) {
	this.abnor = abnor;
}
public WebElement getAbnormcam7() {
	return abnormcam7;
}
public void setAbnormcam7(WebElement abnormcam7) {
	this.abnormcam7 = abnormcam7;
}
public WebElement getAsscrop7() {
	return asscrop7;
}
public void setAsscrop7(WebElement asscrop7) {
	this.asscrop7 = asscrop7;
}
public WebElement getAsssubmit() {
	return asssubmit;
}
public void setAsssubmit(WebElement asssubmit) {
	this.asssubmit = asssubmit;
}
public WebElement getAsssubmityes() {
	return asssubmityes;
}
public void setAsssubmityes(WebElement asssubmityes) {
	this.asssubmityes = asssubmityes;
}
public WebElement getAssuplaod() {
	return assuplaod;
}
public void setAssuplaod(WebElement assuplaod) {
	this.assuplaod = assuplaod;
}
@FindBy(id="com.DvaraEDairy.fposasdev:id/next_3")private WebElement lacnext;
//breeding details
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[1]/android.widget.TextView")private WebElement bdpregtype;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[3]")private WebElement bdselect;
@FindBy(id="com.DvaraEDairy.fposasdev:id/id_54")private WebElement dss;
@FindBy(id="com.DvaraEDairy.fposasdev:id/id_sp16")private WebElement nofservice;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[6]")private WebElement selectservice;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[3]/android.widget.TextView")private WebElement uptype;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[2]")private WebElement upselect;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[4]/android.widget.TextView")private WebElement uttype;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[2]")private WebElement utselect;
@FindBy(id="com.DvaraEDairy.fposasdev:id/next_4")private WebElement bdnext;
//feeddetails
@FindBy(id="com.DvaraEDairy.fposasdev:id/id_19")private WebElement gf;
@FindBy(id="com.DvaraEDairy.fposasdev:id/id_21")private WebElement df;
@FindBy(id="com.DvaraEDairy.fposasdev:id/id_58")private WebElement cf;
@FindBy(id="com.DvaraEDairy.fposasdev:id/next11")private WebElement fdsnext;
//
@FindBy(id="com.DvaraEDairy.fposasdev:id/next_6")private WebElement localfeednext;
public WebElement getLocalfeednext() {
	return localfeednext;
}
public void setLocalfeednext(WebElement localfeednext) {
	this.localfeednext = localfeednext;
}
//preventivecare
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[1]/android.widget.TextView")private WebElement Pdcstatus;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[3]")private WebElement ddyes;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[2]/android.widget.TextView")private WebElement vstatus;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[3]")private WebElement vyes;
@FindBy(id="com.DvaraEDairy.fposasdev:id/id_40")private WebElement vexpense;
@FindBy(id="com.DvaraEDairy.fposasdev:id/id_41")private WebElement majordisease;
@FindBy(id="com.DvaraEDairy.fposasdev:id/next10")private WebElement pcnext;
//farmerquestion
@FindBy(id="com.DvaraEDairy.fposasdev:id/et_question")private WebElement farmerquestion;
@FindBy(id="com.DvaraEDairy.fposasdev:id/btn_question_next")private WebElement farmerques;
//photo
@FindBy(id="com.DvaraEDairy.fposasdev:id/photo1")private WebElement fullsideview;
@FindBy(id="com.DvaraEDairy.fposasdev:id/camera_icon")private WebElement asscam1;
@FindBy(id="com.DvaraEDairy.fposasdev:id/crop_image_menu_crop")private WebElement asscrop1;

//muzzle
@FindBy(id="com.DvaraEDairy.fposasdev:id/allMuzzleImage")private WebElement assmuzzle;
@FindBy(id="com.DvaraEDairy.fposasdev:id/okButton")private WebElement asscontinue;
@FindBy(id="com.DvaraEDairy.fposasdev:id/autoCapture")private WebElement assauto;
//leftside
@FindBy(id="com.DvaraEDairy.fposasdev:id/photo5")private WebElement leftside;
@FindBy(id="com.DvaraEDairy.fposasdev:id/camera_icon")private WebElement asscam2;
@FindBy(id="com.DvaraEDairy.fposasdev:id/crop_image_menu_crop")private WebElement asscrop2;
//leftsideudder
@FindBy(id="com.DvaraEDairy.fposasdev:id/photo6")private WebElement Lsudder;
@FindBy(id="com.DvaraEDairy.fposasdev:id/camera_icon")private WebElement asscam3;
@FindBy(id="com.DvaraEDairy.fposasdev:id/crop_image_menu_crop")private WebElement asscrop3;
//backside
@FindBy(id="com.DvaraEDairy.fposasdev:id/photo7")private WebElement bsideview;
@FindBy(id="com.DvaraEDairy.fposasdev:id/camera_icon")private WebElement asscam4;
@FindBy(id="com.DvaraEDairy.fposasdev:id/crop_image_menu_crop")private WebElement asscrop4;
//rightsideshoulder
@FindBy(id="com.DvaraEDairy.fposasdev:id/photo8")private WebElement rsidetail;
@FindBy(id="com.DvaraEDairy.fposasdev:id/camera_icon")private WebElement asscam5;
@FindBy(id="com.DvaraEDairy.fposasdev:id/crop_image_menu_crop")private WebElement asscrop5;
//rightsideudder
@FindBy(id="com.DvaraEDairy.fposasdev:id/photo9")private WebElement rightsideu;
@FindBy(id="com.DvaraEDairy.fposasdev:id/camera_icon")private WebElement asscam6;
@FindBy(id="com.DvaraEDairy.fposasdev:id/crop_image_menu_crop")private WebElement asscrop6;
//abnorm
@FindBy(id="com.DvaraEDairy.fposasdev:id/photo10")private WebElement abnor;
@FindBy(id="com.DvaraEDairy.fposasdev:id/make_photo_button")private WebElement abnormcam7;
@FindBy(id="com.DvaraEDairy.fposasdev:id/crop_image_menu_crop")private WebElement asscrop7;
//submit
@FindBy(id="com.DvaraEDairy.fposasdev:id/submit")private WebElement asssubmit;
@FindBy(id="android:id/button1")private WebElement asssubmityes;
//upload
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.LinearLayout[3]/android.widget.FrameLayout/android.widget.RelativeLayout")private WebElement assuplaod;


}


