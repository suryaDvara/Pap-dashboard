package Pappom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Pappreventivecare {
	public WebDriver driver;
	public Pappreventivecare(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);

    }
	//preventive care details
	//Deworming status
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[1]/android.widget.TextView")private WebElement Deworming;
	public WebElement getDeworming() {
		return Deworming;
	}
	public void setDeworming(WebElement deworming) {
		Deworming = deworming;
	}
	public WebElement getDewormingclick() {
		return Dewormingclick;
	}
	public void setDewormingclick(WebElement dewormingclick) {
		Dewormingclick = dewormingclick;
	}
	public WebElement getDewormingDateselect() {
		return DewormingDateselect;
	}
	public void setDewormingDateselect(WebElement dewormingDateselect) {
		DewormingDateselect = dewormingDateselect;
	}
	public WebElement getDewormingcal() {
		return Dewormingcal;
	}
	public void setDewormingcal(WebElement dewormingcal) {
		Dewormingcal = dewormingcal;
	}
	public WebElement getDewormingok() {
		return Dewormingok;
	}
	public void setDewormingok(WebElement dewormingok) {
		Dewormingok = dewormingok;
	}
	public WebElement getvaccines() {
		return vaccines;
	}
	public void setVaccines(WebElement vaccines) {
		this.vaccines = vaccines;
	}
	public WebElement getvaccineclick() {
		return vaccineclick;
	}
	public void setvaccineclick(WebElement vaccineclick) {
		this.vaccineclick = vaccineclick;
	}
	public WebElement getVname() {
		return vname;
	}
	public void setVname(WebElement vname) {
		this.vname = vname;
	}
	public WebElement getVnameselect() {
		return vnameselect;
	}
	public void setVnameselect(WebElement vnameselect) {
		this.vnameselect = vnameselect;
	}
	public WebElement getVaccinecal() {
		return vaccinecal;
	}
	public void setVaccinecal(WebElement vaccinecal) {
		this.vaccinecal = vaccinecal;
	}
	public WebElement getVaccinecdate() {
		return vaccinecdate;
	}
	public void setVaccinecdate(WebElement vaccinecdate) {
		this.vaccinecdate = vaccinecdate;
	}
	public WebElement getVetexp() {
		return vetexp;
	}
	public void setVetexp(WebElement vetexp) {
		this.vetexp = vetexp;
	}
	public WebElement getNext6() {
		return Next6;
	}
	public void setNext6(WebElement next6) {
		Next6 = next6;
	}

	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[2]")private WebElement Dewormingclick;

	//date of deworming
	@FindBy(id="com.DvaraEDairy.fposasdev:id/id_39")private WebElement DewormingDateselect;
	@FindBy(xpath="//android.view.View[@content-desc=\"01 December 2022\"]")private WebElement Dewormingcal;
	@FindBy(id="android:id/button1")private WebElement Dewormingok;


	//Vaccination status
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[2]/android.widget.TextView")private WebElement vaccines;
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[2]")private WebElement vaccineclick;
	//vacdatename
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[3]/android.widget.TextView")private WebElement vname;
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[3]")private WebElement vnameselect;
	@FindBy(id="com.DvaraEDairy.fposasdev:id/id_37")private WebElement vaccinecal;
	@FindBy(xpath="//android.view.View[@content-desc=\"07 December 2022\"]")private WebElement vaccinecdate;
	@FindBy(id="android:id/button1")private WebElement vaccineok;
	public WebElement getvaccineok() {
		return vaccineok;
	}
	public void setvaccineok(WebElement vaccineok) {
		this.vaccineok = vaccineok;
	}
	//vetexpense
	@FindBy(id="com.DvaraEDairy.fposasdev:id/id_40")private WebElement vetexp;
	@FindBy(id="com.DvaraEDairy.fposasdev:id/id_41")private WebElement majordiseases;
	public WebElement getMajordiseases() {
		return majordiseases;
	}
	public void setMajordiseases(WebElement majordiseases) {
		this.majordiseases = majordiseases;
	}

	@FindBy(id="com.DvaraEDairy.fposasdev:id/next10")private WebElement Next6;

}
