package Pappom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Papfarmerquestion {
	public WebDriver driver;
	public Papfarmerquestion(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);

    }	
	//farmer question
	@FindBy(id="com.DvaraEDairy.fposasdev:id/et_question")private WebElement question;
	public WebElement getQuestion() {
		return question;
	}
	public void setQuestion(WebElement question) {
		this.question = question;
	}
	public WebElement getNext7() {
		return Next7;
	}
	public void setNext7(WebElement next7) {
		Next7 = next7;
	}

	@FindBy(id="com.DvaraEDairy.fposasdev:id/btn_question_next")private WebElement Next7;


}
