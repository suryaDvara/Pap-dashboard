package Pappom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Paplac {
	public WebDriver driver;
	public Paplac(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);

    }	
	//Lactationdetails
	@FindBy(id="com.DvaraEDairy.fposasdev:id/id_52")private WebElement currentmy;
	public WebElement getCurrentmy() {
		return currentmy;
	}
	public void setCurrentmy(WebElement currentmy) {
		this.currentmy = currentmy;
	}
	public WebElement getPeakmy() {
		return peakmy;
	}
	public void setPeakmy(WebElement peakmy) {
		this.peakmy = peakmy;
	}

	@FindBy(id="com.DvaraEDairy.fposasdev:id/id_53")private WebElement peakmy;
	@FindBy(id="com.DvaraEDairy.fposasdev:id/next_3")private WebElement next3;
	public WebElement getNext3() {
		return next3;
	}
	public void setNext3(WebElement next3) {
		this.next3 = next3;
	}
		
}
