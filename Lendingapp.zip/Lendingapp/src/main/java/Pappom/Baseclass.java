package Pappom;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class Baseclass {
	protected  static AndroidDriver driver;
	public static DesiredCapabilities caps;
	@Test
	public void Android() throws MalformedURLException {
		
	DesiredCapabilities caps = new DesiredCapabilities();
	caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
	caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "12");



	caps.setCapability(MobileCapabilityType.DEVICE_NAME, "sumsung");
	caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");
	caps.setCapability(MobileCapabilityType.UDID, "RZCT80JRFPY");
	caps.setCapability("enableCameraImageInjection", "true");



	caps.setCapability("PackageName", "com.DvaraEDairy.fposasdev");
	caps.setCapability("appActivity", "com.DvaraEDairy.fposasdev");
	URL UI = new URL("http://0.0.0.0:4723/wd/hub");
	driver = new AndroidDriver(UI, caps);
	driver.getDeviceTime();
	driver.activateApp("com.DvaraEDairy.fposasdev");
	}

	
//	public static WebDriver driver1;
    public static String value;
	
   	public static void clickonElement(WebElement element) {
		// singin_btnclick();
		element.click();
	}

	public static void inputonElement(WebElement pass, String data) {
		pass.sendKeys(data);
	}
	public static void inputsendonElement(Alert a4, String data) {
		a4.sendKeys(data);
	}

	public static void geturl(String url) {
		driver.get(url);
		driver.manage().window().maximize();
	}

	public static void close() {
		driver.close();
	}

	public static void dropdown(String type, WebElement element, String value) {
		try {
			Select s = new Select(element);
			if (type.equalsIgnoreCase("byvalue")) {
				s.selectByValue(value);
			} else if (type.equalsIgnoreCase("VisibleText")) {
				s.selectByVisibleText(value);
			} else if (type.equalsIgnoreCase("byIndex")) {
				int index = Integer.parseInt(value);
				s.selectByIndex(index);
			}		
			
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	
	}
	public static void sleep(int milliseconds) {
		try {
			Thread.sleep(milliseconds);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void scrollupanddown(WebElement element) {

		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeAsyncScript("arguments[0].scrollintoview()", element);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void actionClass(String actionName, WebElement element) {

		Actions a = new Actions(driver);
		try {
			if (actionName.equalsIgnoreCase("moveto")) {
				a.moveToElement(element).build().perform();
			} else if (actionName.equalsIgnoreCase("clickon")) {
				a.click(element).build().perform();
			} else if (actionName.equalsIgnoreCase("click")) {
				a.click(element).build().perform();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void implicitwait(int seconds, TimeUnit i) {
		driver.manage().timeouts().implicitlyWait(seconds, i);
	}

//	public static void sleep1(int seconds) throws Throwable {
	//	Thread.sleep(seconds);
	//}
	/*
	 * // public static void fluent_wait(int timeoutseconds,int
	 * pollingseconds,TimeUnit format) { Wait wait =new
	 * FluentWait(driver).withTimeout(30,seconds) .pollingEvery(10, format)
	 * .ignoring(Exception.class); } //
	 */

	public static void takescreenshot(String path) throws Exception {
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		File destination = new File(path);
		FileUtils.copyFile(source, destination);
	}

	public static void endsession(String type) {
		if (type.equalsIgnoreCase("close")) {
			driver.close();
		} else if (type.equalsIgnoreCase("quit")) {
			driver.quit();
		}
	}

	public static void navigate(String type, String value) {
		if (type.equalsIgnoreCase("to")) {
			driver.navigate().to(value);
		}
	}
public static void alert(String type) {

	 Alert a2=driver.switchTo().alert();
	    a2.sendKeys("ar");
	    a2.accept();


}
public static String Testdata(String path,int row_Index,int cell_Index) throws IOException {
	File f=new File(path);
	FileInputStream fis=new FileInputStream(f);
	
	XSSFWorkbook w1=new XSSFWorkbook(fis);
	XSSFSheet SheetAt=w1.getSheetAt(0);
	XSSFRow row=SheetAt.getRow(row_Index);
	XSSFCell cell=row.getCell(cell_Index);
	CellType type=cell.getCellType();
	
	
	if(type.equals(CellType.STRING)){
		value=cell.getStringCellValue();
	}
	else if (type.equals(CellType.NUMERIC)) {
		double numericcellvalue=cell.getNumericCellValue();
		int val= (int)numericcellvalue;
		value=String.valueOf(val);

	}
	return value;	
}	
void Extendreport() {
	ExtentSparkReporter reporter = new ExtentSparkReporter("./ReportPAPapp.html");
	ExtentReports extent = new ExtentReports();
	extent.attachReporter(reporter);
	ExtentTest test= extent.createTest("TC-PAP-VALUECHAINAPP");
	test.assignAuthor("Surya");
	test.assignCategory("End to End Teting");
}


public static void closeBrowser() {
ExtentReports extentReports = new ExtentReports();
extentReports.flush();
}

}
