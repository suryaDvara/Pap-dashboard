package Pappom;

import org.testng.annotations.Test;

public class Papapprunner {
	@Test
	public void testcase() throws Throwable  {
	Papvaluechain pap=new Papvaluechain();
}
	
	

}
