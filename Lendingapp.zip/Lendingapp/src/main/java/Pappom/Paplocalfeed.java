package Pappom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Paplocalfeed {
	public WebDriver driver;
	public Paplocalfeed(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);

    }	
	//Local Feed ingredients
	@FindBy(id="com.DvaraEDairy.fposasdev:id/id_24")private WebElement Localfeed1 ;
	public WebElement getLocalfeed1() {
		return Localfeed1;
	}
	public void setLocalfeed1(WebElement localfeed1) {
		Localfeed1 = localfeed1;
	}
	public WebElement getQuantity1() {
		return Quantity1;
	}
	public void setQuantity1(WebElement quantity1) {
		Quantity1 = quantity1;
	}
	public WebElement getNext5() {
		return Next5;
	}
	public void setNext5(WebElement next5) {
		Next5 = next5;
	}

	@FindBy(id="com.DvaraEDairy.fposasdev:id/id_25")private WebElement Quantity1;
	@FindBy(id="com.DvaraEDairy.fposasdev:id/next_6")private WebElement Next5;
	
}
