package Pappom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Papedit {
	public WebDriver driver;
	public Papedit(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
    }
	//edit
@FindBy(id="com.DvaraEDairy.fposasdev:id/edit")private WebElement edit;
public WebDriver getDriver() {
	return driver;
}
public void setDriver(WebDriver driver) {
	this.driver = driver;
}
public WebElement getEdit() {
	return edit;
}
public void setEdit(WebElement edit) {
	this.edit = edit;
}
public WebElement getYesbutton() {
	return yesbutton;
}
public void setYesbutton(WebElement yesbutton) {
	this.yesbutton = yesbutton;
}
public WebElement getBnext1() {
	return Bnext1;
}
public void setBnext1(WebElement bnext1) {
	Bnext1 = bnext1;
}
public WebElement getLnext2() {
	return Lnext2;
}
public void setLnext2(WebElement lnext2) {
	Lnext2 = lnext2;
}
public WebElement getNext3() {
	return next3;
}
public void setNext3(WebElement next3) {
	this.next3 = next3;
}
public WebElement getNext4() {
	return Next4;
}
public void setNext4(WebElement next4) {
	Next4 = next4;
}
public WebElement getNext5() {
	return Next5;
}
public void setNext5(WebElement next5) {
	Next5 = next5;
}
public WebElement getNext6() {
	return Next6;
}
public void setNext6(WebElement next6) {
	Next6 = next6;
}
public WebElement getSubmitt() {
	return Submitt;
}
public void setSubmitt(WebElement submitt) {
	Submitt = submitt;
}
@FindBy(id="android:id/button1")private WebElement yesbutton;
@FindBy(id="com.DvaraEDairy.fposasdev:id/next_1")private WebElement Bnext1;
@FindBy(id="com.DvaraEDairy.fposasdev:id/next_3")private WebElement Lnext2;
@FindBy(id="com.DvaraEDairy.fposasdev:id/next11")private WebElement next3;
@FindBy(id="com.DvaraEDairy.fposasdev:id/next_6")private WebElement Next4;
@FindBy(id="com.DvaraEDairy.fposasdev:id/next10")private WebElement Next5;
@FindBy(id="com.DvaraEDairy.fposasdev:id/btn_question_next")private WebElement Next6;
@FindBy(id="com.DvaraEDairy.fposasdev:id/submit")private WebElement Submitt;
@FindBy(id="android:id/button1")private WebElement submityes;
public WebElement getsubmityes() {
	return submityes;
}
public void setsubmityes(WebElement submityes) {
	this.submityes = submityes;
}
	
}
