package Pappom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumBy;

public class Papaddbovine extends Baseclass{
	public WebDriver driver;
	public Papaddbovine(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);

    }	

	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.LinearLayout[1]/android.widget.FrameLayout/android.widget.RelativeLayout")private WebElement Addbovine;
	public WebElement getAddbovine() {
		return Addbovine;
	}
	public void setAddbovine(WebElement Addbovine) {
		Addbovine = Addbovine;
	}
	public WebElement getFphno() {
		return Fphno;
	}
	public void setFphno(WebElement Fphno) {
		Fphno = Fphno;
	}
	public WebElement getwhatsappcheckbox() {
		return whatsappcheckbox;
	}
	public void setwhatsappcheckbox(WebElement whatsappcheckbox) {
		this.whatsappcheckbox = whatsappcheckbox;
	}
	public WebElement getwhatsappno() {
		return whatsappno;
	}
	public void setwhatsappno(WebElement whatsappno) {
		this.whatsappno = whatsappno;
	}
	public WebElement getselect() {
		return select;
	}
	public void setselect(WebElement select) {
		this.select = select;
	}
	public WebElement getselectlang() {
		return selectlang;
	}
	public void setselectlang(WebElement selectlang) {
		this.selectlang = selectlang;
	}
	public WebElement getfarmername() {
		return farmername;
	}
	public void setfarmername(WebElement farmername) {
		this.farmername = farmername;
	}
	public WebElement getvillagename() {
		return villagename;
	}
	public void setvillagename(WebElement villagename) {
		this.villagename = villagename;
	}
	public WebElement getnext1() {
		return next1;
	}
	public void setnext1(WebElement next1) {
		this.next1 = next1;
	}
	
	
	@FindBy(id="com.DvaraEDairy.fposasdev:id/id_3")private WebElement Fphno;
	@FindBy(id="com.DvaraEDairy.fposasdev:id/whatsapp")private WebElement whatsappcheckbox;
	@FindBy(id="com.DvaraEDairy.fposasdev:id/whatsappnumber")private WebElement whatsappno;
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner/android.widget.TextView")private WebElement select;
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[2]")private WebElement selectlang;
	@FindBy(id="com.DvaraEDairy.fposasdev:id/id_1")private WebElement farmername;
	@FindBy(id="com.DvaraEDairy.fposasdev:id/id_2")private WebElement villagename;
	@FindBy(id="com.DvaraEDairy.fposasdev:id/next1")private WebElement next1;
	@FindBy(id="com.DvaraEDairy.fposasdev:id/id_sp106")private WebElement click1;
	public WebElement getclick1() {
		return click1;
	}
	public void setclick1(WebElement click1) {
		this.click1 = click1;
	}
	//System.out.println("Successfully entered farmer details");

@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout"
		+ "/android.widget.ListView/android.widget.TextView[2]")private WebElement selectc1;
public WebElement getselectc1() {
	return selectc1;
}
public void setSelectc1(WebElement selectc1) {
	this.selectc1 = selectc1;
}
public WebElement getselectc2() {
	return selectc2;
}
public void setselectc2(WebElement selectc2) {
	this.selectc2 = selectc2;
}
public WebElement getpetname() {
	return petname;
}
public void setPetname(WebElement petname) {
	this.petname = petname;
}
public WebElement getdslcalving() {
	return dslcalving;
}
public void setDslcalving(WebElement dslcalving) {
	this.dslcalving = dslcalving;
}

@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout"
		+ "/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[2]/android.widget.TextView")private WebElement selectc2;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[3]")private WebElement s3;
public WebElement gets3() {
	return s3;
}
public void sets3(WebElement s3) {
	this.s3 = s3;
}

@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.EditText")private WebElement petname;	
@FindBy(id="com.DvaraEDairy.fposasdev:id/id_48")private WebElement dslcalving;	
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[3]/android.widget.TextView")private WebElement pregstatus;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[2]")private WebElement pregc1;


	//No of months
	//Thread.sleep(2000);
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[4]/android.widget.TextView")private WebElement nopreg;
public WebElement getpregstatus() {
	return pregstatus;
}
public void setpregstatus(WebElement pregstatus) {
	this.pregstatus = pregstatus;
}
public WebElement getpregc1() {
	return pregc1;
}
public void setpregc1(WebElement pregc1) {
	this.pregc1 = pregc1;
}
public WebElement getNopreg() {
	return nopreg;
}
public void setnopreg(WebElement nopreg) {
	this.nopreg = nopreg;
}
public WebElement getpregc2() {
	return pregc2;
}
public void setpregc2(WebElement pregc2) {
	this.pregc2 = pregc2;
}


@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[2]")private WebElement pregc2;


	//Milking status
	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[5]/android.widget.TextView")private WebElement milkingstatus;
	public WebElement getmilkingstatus() {
		return milkingstatus;
	}
	public void setmilkingstatus(WebElement milkingstatus) {
		this.milkingstatus = milkingstatus;
	}
	public WebElement getmilkingclick() {
		return milkingclick;
	}
	public void setmilkingclick(WebElement milkingclick) {
		this.milkingclick = milkingclick;
	}

	@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[2]")private WebElement milkingclick;

	//lactation
	@FindBy(id="com.DvaraEDairy.fposasdev:id/id_47")private WebElement lact;
	public WebElement getLact() {
		return lact;
	}
	public void setLact(WebElement lact) {
		this.lact = lact;
	}
	
	//onboarding

@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[4]/android.widget.TextView")private WebElement onboardings;
public WebElement getOnboardings() {
	return onboardings;
}
public void setOnboardings(WebElement onboardings) {
	this.onboardings = onboardings;
}
public WebElement getOnbclick() {
	return onbclick;
}
public void setOnbclick(WebElement onbclick) {
	this.onbclick = onbclick;
}
public WebElement getAssessment() {
	return assessment;
}
public void setAssessment(WebElement assessment) {
	this.assessment = assessment;
}
public WebElement getAssessselect() {
	return assessselect;
}
public void setAssessselect(WebElement assessselect) {
	this.assessselect = assessselect;
}
public WebElement getNext2() {
	return next2;
}
public void setNext2(WebElement next2) {
	this.next2 = next2;
}

@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[2]")private WebElement onbclick;
//assessment
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Spinner[5]/android.widget.TextView")private WebElement assessment;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.TextView[2]")private WebElement assessselect;
@FindBy(id="com.DvaraEDairy.fposasdev:id/next_1")private WebElement next2;


//upload
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.RelativeLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.LinearLayout[2]/androidx.recyclerview.widget.RecyclerView/android.widget.LinearLayout[3]/android.widget.FrameLayout/android.widget.RelativeLayout")private WebElement upload;
public WebElement getUpload() {
	return upload;
}
public void setUpload(WebElement upload) {
	this.upload = upload;
}







}
