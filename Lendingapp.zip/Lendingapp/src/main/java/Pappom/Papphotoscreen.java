package Pappom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumBy;

public class Papphotoscreen {
	public WebDriver driver;
	public  Papphotoscreen(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);

    }	
@FindBy(id="com.DvaraEDairy.fposasdev:id/photo1")private WebElement fullviewclick;
public WebElement getFullviewclick() {
	return fullviewclick;
}
public void setFullviewclick(WebElement fullviewclick) {
	this.fullviewclick = fullviewclick;
}
public WebElement getPhbt1() {
	return phbt1;
}
public void setPhbt1(WebElement phbt1) {
	this.phbt1 = phbt1;
}
public WebElement getCrop1() {
	return crop1;
}
public void setCrop1(WebElement crop1) {
	this.crop1 = crop1;
}
@FindBy(id="com.DvaraEDairy.fposasdev:id/make_photo_button")private WebElement phbt1 ;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[1]/android.view.ViewGroup/androidx.appcompat.widget.LinearLayoutCompat/android.widget.TextView[3]")private WebElement crop1;


//muzzle photo2
@FindBy(id="com.DvaraEDairy.fposasdev:id/allMuzzleImage")private WebElement muzzle;
public WebElement getMuzzle() {
	return muzzle;
}
public void setMuzzle(WebElement muzzle) {
	this.muzzle = muzzle;
}
public WebElement getContinue1() {
	return continue1;
}
public void setContinue1(WebElement continue1) {
	this.continue1 = continue1;
}
public WebElement getAuto() {
	return auto;
}
public void setAuto(WebElement auto) {
	this.auto = auto;
}
@FindBy(id="com.DvaraEDairy.fposasdev:id/okButton")private WebElement continue1;
@FindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.RelativeLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.Switch")private WebElement auto;

//Leftside
@FindBy(id="com.DvaraEDairy.fposasdev:id/photo5")private WebElement Leftside;
public WebElement getLeftside() {
	return Leftside;
}
public void setLeftside(WebElement leftside) {
	Leftside = leftside;
}
public WebElement getCam2() {
	return cam2;
}
public void setCam2(WebElement cam2) {
	this.cam2 = cam2;
}
public WebElement getCrop2() {
	return crop2;
}
public void setCrop2(WebElement crop2) {
	this.crop2 = crop2;
}
@FindBy(id="com.DvaraEDairy.fposasdev:id/camera_icon")private WebElement cam2;
@FindBy(id="com.DvaraEDairy.fposasdev:id/crop_image_menu_crop")private WebElement crop2;
//leftsideudder
@FindBy(id="com.DvaraEDairy.fposasdev:id/photo6")private WebElement Leftsideudder;
public WebElement getLeftsideudder() {
	return Leftsideudder;
}
public void setLeftsideudder(WebElement Leftsideudder) {
	Leftsideudder = Leftsideudder;
}
public WebElement getCam3() {
	return cam3;
}
public void setCam3(WebElement cam3) {
	this.cam3 = cam3;
}
public WebElement getCrop3() {
	return crop3;
}
public void setCrop3(WebElement crop3) {
	this.crop3 = crop3;
}
@FindBy(id="com.DvaraEDairy.fposasdev:id/make_photo_button")private WebElement cam3;
@FindBy(id="com.DvaraEDairy.fposasdev:id/crop_image_menu_crop")private WebElement crop3;
//Backsideview
@FindBy(id="com.DvaraEDairy.fposasdev:id/photo7")private WebElement backside;
public WebElement getbackside() {
	return backside;
}
public void setBackside(WebElement backside) {
	this.backside = backside;
}
public WebElement getCam4() {
	return cam4;
}
public void setCam4(WebElement cam4) {
	this.cam4 = cam4;
}
public WebElement getCrop4() {
	return crop4;
}
public void setCrop4(WebElement crop4) {
	this.crop4 = crop4;
}
@FindBy(id="com.DvaraEDairy.fposasdev:id/make_photo_button")private WebElement cam4;
@FindBy(id="com.DvaraEDairy.fposasdev:id/crop_image_menu_crop")private WebElement crop4;
//Rightside
@FindBy(id="com.DvaraEDairy.fposasdev:id/photo8")private WebElement rightside;
public WebElement getrightside() {
	return rightside;
}
public void setRightside(WebElement rightside) {
	rightside = rightside;
}
public WebElement getCam5() {
	return cam5;
}
public void setCam5(WebElement cam5) {
	this.cam5 = cam5;
}
public WebElement getCrop5() {
	return crop5;
}
public void setCrop5(WebElement crop5) {
	this.crop5 = crop5;
}
@FindBy(id="com.DvaraEDairy.fposasdev:id/camera_icon")private WebElement cam5;
@FindBy(id="com.DvaraEDairy.fposasdev:id/crop_image_menu_crop")private WebElement crop5;
//
@FindBy(id="com.DvaraEDairy.fposasdev:id/photo9")private WebElement rightideudder;
public WebElement getrightideudder() {
	return rightideudder;
}
public void setrightideudder(WebElement rightideudder) {
	this.rightideudder = rightideudder;
}
public WebElement getCam6() {
	return cam6;
}
public void setCam6(WebElement cam6) {
	this.cam6 = cam6;
}
public WebElement getCrop6() {
	return crop6;
}
public void setCrop6(WebElement crop6) {
	this.crop6 = crop6;
}
@FindBy(id="com.DvaraEDairy.fposasdev:id/make_photo_button")private WebElement cam6;
@FindBy(id="com.DvaraEDairy.fposasdev:id/crop_image_menu_crop")private WebElement crop6;
//abnormalitie
@FindBy(id="com.DvaraEDairy.fposasdev:id/photo10")private WebElement abnormal;
public WebElement getAbnormal() {
	return abnormal;
}
public void setAbnormal(WebElement abnormal) {
	this.abnormal = abnormal;
}
public WebElement getCam7() {
	return cam7;
}
public void setCam7(WebElement cam7) {
	this.cam7 = cam7;
}
public WebElement getCrop7() {
	return crop7;
}
public void setCrop7(WebElement crop7) {
	this.crop7 = crop7;
}
@FindBy(id="com.DvaraEDairy.fposasdev:id/make_photo_button")private WebElement cam7;
@FindBy(id="com.DvaraEDairy.fposasdev:id/crop_image_menu_crop")private WebElement crop7;

}
