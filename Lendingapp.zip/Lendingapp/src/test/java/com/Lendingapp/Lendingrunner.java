package com.Lendingapp;

import org.testng.annotations.Test;

public class Lendingrunner {
	@Test
	public void testcase() throws Throwable  {
	
	Lendingapp Lending=new Lendingapp();
	Lending.testcase01();
	Lending.Usersetting();
	
}
}