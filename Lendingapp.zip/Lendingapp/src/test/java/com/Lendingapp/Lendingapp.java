package com.Lendingapp;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Lendingpom.Lendingmanager;
import Pappom.Baseclass;
import Pappom.Papmanager;

public class Lendingapp extends Baseclass {
 
	@SuppressWarnings("unused")
	ExtentSparkReporter reporter = new ExtentSparkReporter("./ReportPAPLendingapp.html");
	ExtentReports extent = new ExtentReports();
	Lendingmanager Pappom=new Lendingmanager(driver);	
	
	   
@Test
	public void testcase01() throws FileNotFoundException, IOException {	 
	
	Properties prop = new Properties();
	prop.load(new FileInputStream("./PapLendingapp.properties"));
		
	Logger  log=Logger.getLogger(Lendingapp.class);
	PropertyConfigurator.configure("Log4j.properties"); 
	
		
		Lendingmanager Pappom=new Lendingmanager(driver);
		
		ExtentTest test1=extent.createTest("TC-001-HOME SCREEN");
		test1.assignAuthor("Surya");
		test1.assignCategory("End to End Teting");
        //Thread.sleep(2000);
        inputonElement(Pappom.get_Instance_phno().getPhoneno(),prop.getProperty("phoneno"));
        driver.hideKeyboard();
        clickonElement(Pappom.get_Instance_phno().getPrivacypolicy());
        clickonElement(Pappom.get_Instance_phno().getAcceptpp());
        
		
        //Partner
        clickonElement(Pappom.get_Instance_phno().getContinuep());
        clickonElement(Pappom.get_Instance_phno().getok());
		
        //Verification
        implicitwait(3000,TimeUnit.SECONDS);
        driver.hideKeyboard();
        inputonElement(Pappom.get_Instance_phno().getOtpverify(),prop.getProperty("OTP"));
        //implicitwait(1000,TimeUnit.SECONDS);
	
        clickonElement(Pappom.get_Instance_phno().getVerify());
        log.info("Login Successfully");
      
            }
@Test
public void Usersetting() throws Throwable, IOException {
	extent.attachReporter(reporter);
	ExtentTest test= extent.createTest("TC-PAP-LendingAPP");
	
	Properties prop = new Properties();
	prop.load(new FileInputStream("./PapLendingapp.properties"));
		
	Logger  log=Logger.getLogger(Lendingapp.class);
	PropertyConfigurator.configure("Log4j.properties"); 
	
	//Usersetting
implicitwait(3000,TimeUnit.SECONDS);

clickonElement(Pappom.get_Instance_usersetting().getusersetting1());
Thread.sleep(2000);
clickonElement(Pappom.get_Instance_usersetting().getup());
//    clickonElement(Pappom.get_Instance_usersetting().getusedit());
clickonElement(Pappom.get_Instance_usersetting().getUsername());
inputonElement(Pappom.get_Instance_usersetting().getUsername(),prop.getProperty("Username"));
inputonElement(Pappom.get_Instance_usersetting().getOrgs(),prop.getProperty("Org"));
clickonElement(Pappom.get_Instance_usersetting().getUpdetails());
log.info("Userprofile");
//langtamil
extent.flush();
ExtentTest test3=extent.createTest("TC-003- ALL LANGUAGE");
implicitwait(3000,TimeUnit.SECONDS);
clickonElement(Pappom.get_Instance_usersetting().getus1());
Thread.sleep(2000);
clickonElement(Pappom.get_Instance_usersetting().gettamil());
clickonElement(Pappom.get_Instance_usersetting().gettr1());
clickonElement(Pappom.get_Instance_usersetting().gettok2());
log.info("Tamil");
//lang guja/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView
extent.flush();
implicitwait(3000,TimeUnit.SECONDS);
clickonElement(Pappom.get_Instance_usersetting().getus2());
implicitwait(3000,TimeUnit.SECONDS);
clickonElement(Pappom.get_Instance_usersetting().getgujarathi());
clickonElement(Pappom.get_Instance_usersetting().getg1());
clickonElement(Pappom.get_Instance_usersetting().getgok2());
log.info("Hindi");
//Hindi
implicitwait(3000,TimeUnit.SECONDS);
clickonElement(Pappom.get_Instance_usersetting().getus4());
implicitwait(3000,TimeUnit.SECONDS);
clickonElement(Pappom.get_Instance_usersetting().getkannada());
clickonElement(Pappom.get_Instance_usersetting().getK1());
clickonElement(Pappom.get_Instance_usersetting().getKok2());
log.info("Marathi");
//Marathi
implicitwait(3000,TimeUnit.SECONDS);
clickonElement(Pappom.get_Instance_usersetting().getus5());
Thread.sleep(2000);
clickonElement(Pappom.get_Instance_usersetting().getMarathi());
clickonElement(Pappom.get_Instance_usersetting().getm1());
clickonElement(Pappom.get_Instance_usersetting().getmok2());
log.info("Telugu");
//Telugu
Thread.sleep(2000);

clickonElement(Pappom.get_Instance_usersetting().getUs6());
Thread.sleep(2000);
clickonElement(Pappom.get_Instance_usersetting().gettelugu());
clickonElement(Pappom.get_Instance_usersetting().gettelugu1());
clickonElement(Pappom.get_Instance_usersetting().gettelok2());
log.info("English");
//English
implicitwait(3000,TimeUnit.SECONDS);
 
clickonElement(Pappom.get_Instance_usersetting().getus7());
Thread.sleep(2000);
clickonElement(Pappom.get_Instance_usersetting().getEnglish());
clickonElement(Pappom.get_Instance_usersetting().getEok2());
clickonElement(Pappom.get_Instance_usersetting().getEngok2());
log.info("Refresh");
//Refresh

ExtentTest test4=extent.createTest("TC-004- USER SETTING -REFRESH");

implicitwait(3000,TimeUnit.SECONDS);
clickonElement(Pappom.get_Instance_usersetting().getus8());
 implicitwait(3000,TimeUnit.SECONDS);
clickonElement(Pappom.get_Instance_usersetting().getrefresh());
log.info("Customer care");
extent.flush();
ExtentTest test5=extent.createTest("TC-005- USER SETTING -customercare");

//customer
implicitwait(3000,TimeUnit.SECONDS);
clickonElement(Pappom.get_Instance_usersetting().getcs());
Thread.sleep(2000);
clickonElement(Pappom.get_Instance_usersetting().getcs1());
Thread.sleep(2000);
clickonElement(Pappom.get_Instance_usersetting().getclose());
log.info("Version 22.09.11");
extent.flush();
ExtentTest test6=extent.createTest("TC-006- USER SETTING -Version");

//version
 implicitwait(3000,TimeUnit.SECONDS);
clickonElement(Pappom.get_Instance_usersetting().getv1());
implicitwait(3000,TimeUnit.SECONDS);
clickonElement(Pappom.get_Instance_usersetting().getVersion());
extent.flush();
//WebElement version= driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[7]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView"));
//version.getText();
//version.click();

}

		
 	}

