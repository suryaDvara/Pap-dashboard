package Runnerpapvaluechain;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.Papdashboard.Papdrunner;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import Pappom.Baseclass;
import Pappom.Papmanager;
import pom.Manager;

public class Homescreen extends Baseclass {
	
	@Test
	public void testcase() throws Throwable {
	Papmanager Pappom=new Papmanager(driver);

	 Properties prop = new Properties();
	prop.load(new FileInputStream("./Papapp.properties"));
		
		
		Logger  log=Logger.getLogger(Runnerpapmobileapp.class);
		PropertyConfigurator.configure("Log4j.properties");
					
	

	ExtentReports extent=new ExtentReports();
		{
		ExtentTest test1=extent.createTest("TC-001-HOME SCREEN");

        //Thread.sleep(2000);
        inputonElement(Pappom.get_Instance_phno().getPhoneno(),prop.getProperty("phoneno"));
        driver.hideKeyboard();
        clickonElement(Pappom.get_Instance_phno().getPrivacypolicy());
        clickonElement(Pappom.get_Instance_phno().getAcceptpp());
        
		
        //Partner
        clickonElement(Pappom.get_Instance_phno().getContinuep());
        clickonElement(Pappom.get_Instance_phno().getok());
		
        //Verification
        implicitwait(3000,TimeUnit.SECONDS);
        driver.hideKeyboard();
        inputonElement(Pappom.get_Instance_phno().getOtpverify(),prop.getProperty("OTP"));
        //implicitwait(1000,TimeUnit.SECONDS);
	
        clickonElement(Pappom.get_Instance_phno().getVerify());
        log.info("Login Successfully");
        extent.flush();

		}

		ExtentTest test2=extent.createTest("TC-002-USER SETTINGS");
        //Usersetting
        implicitwait(3000,TimeUnit.SECONDS);
        
        clickonElement(Pappom.get_Instance_usersetting().getUsersetting1());
        Thread.sleep(2000);
        clickonElement(Pappom.get_Instance_usersetting().getup());
        clickonElement(Pappom.get_Instance_usersetting().getusedit());
        clickonElement(Pappom.get_Instance_usersetting().getUsername());
        inputonElement(Pappom.get_Instance_usersetting().getUsername(),prop.getProperty("Username"));
        inputonElement(Pappom.get_Instance_usersetting().getOrgs(),prop.getProperty("Org"));
        clickonElement(Pappom.get_Instance_usersetting().getUpdetails());
        log.info("Userprofile");
        //langtamil
        extent.flush();
        ExtentTest test3=extent.createTest("TC-003- ALL LANGUAGE");
        implicitwait(3000,TimeUnit.SECONDS);
        clickonElement(Pappom.get_Instance_usersetting().getus1());
        Thread.sleep(2000);
        clickonElement(Pappom.get_Instance_usersetting().gettamil());
        clickonElement(Pappom.get_Instance_usersetting().gettr1());
        clickonElement(Pappom.get_Instance_usersetting().gettok2());
        log.info("Tamil");
        //lang guja/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView
        extent.flush();
        implicitwait(3000,TimeUnit.SECONDS);
        clickonElement(Pappom.get_Instance_usersetting().getus2());
        implicitwait(3000,TimeUnit.SECONDS);
        clickonElement(Pappom.get_Instance_usersetting().getgujarathi());
        clickonElement(Pappom.get_Instance_usersetting().getg1());
        clickonElement(Pappom.get_Instance_usersetting().getgok2());
        log.info("Hindi");
        //Hindi
        implicitwait(3000,TimeUnit.SECONDS);
        clickonElement(Pappom.get_Instance_usersetting().getus4());
        implicitwait(3000,TimeUnit.SECONDS);
		clickonElement(Pappom.get_Instance_usersetting().getkannada());
		clickonElement(Pappom.get_Instance_usersetting().getK1());
		clickonElement(Pappom.get_Instance_usersetting().getKok2());
		log.info("Marathi");
		//Marathi
		implicitwait(3000,TimeUnit.SECONDS);
		clickonElement(Pappom.get_Instance_usersetting().getus5());
		Thread.sleep(2000);
		clickonElement(Pappom.get_Instance_usersetting().getMarathi());
		clickonElement(Pappom.get_Instance_usersetting().getm1());
		clickonElement(Pappom.get_Instance_usersetting().getmok2());
		log.info("Telugu");
		//Telugu
		Thread.sleep(2000);
		
		clickonElement(Pappom.get_Instance_usersetting().getUs6());
		Thread.sleep(2000);
		clickonElement(Pappom.get_Instance_usersetting().gettelugu());
		clickonElement(Pappom.get_Instance_usersetting().gettelugu1());
		clickonElement(Pappom.get_Instance_usersetting().gettelok2());
		log.info("English");
		//English
		implicitwait(3000,TimeUnit.SECONDS);
		 
		clickonElement(Pappom.get_Instance_usersetting().getus7());
		Thread.sleep(2000);
		clickonElement(Pappom.get_Instance_usersetting().getEnglish());
		clickonElement(Pappom.get_Instance_usersetting().getEok2());
		clickonElement(Pappom.get_Instance_usersetting().getEngok2());
		log.info("Refresh");
		//Refresh
        
		ExtentTest test4=extent.createTest("TC-004- USER SETTING -REFRESH");

		implicitwait(3000,TimeUnit.SECONDS);
		clickonElement(Pappom.get_Instance_usersetting().getus8());
		 implicitwait(3000,TimeUnit.SECONDS);
		clickonElement(Pappom.get_Instance_usersetting().getrefresh());
		log.info("Customer care");
		extent.flush();
		ExtentTest test5=extent.createTest("TC-005- USER SETTING -customercare");

		//customer
		implicitwait(3000,TimeUnit.SECONDS);
		clickonElement(Pappom.get_Instance_usersetting().getcs());
		Thread.sleep(2000);
		clickonElement(Pappom.get_Instance_usersetting().getcs1());
		Thread.sleep(2000);
		clickonElement(Pappom.get_Instance_usersetting().getclose());
		log.info("Version 22.09.11");
		extent.flush();
		ExtentTest test6=extent.createTest("TC-006- USER SETTING -Version");

		//version
		 implicitwait(3000,TimeUnit.SECONDS);
		clickonElement(Pappom.get_Instance_usersetting().getv1());
	    implicitwait(3000,TimeUnit.SECONDS);
		clickonElement(Pappom.get_Instance_usersetting().getVersion());
		extent.flush();
		//WebElement version= driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[7]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView"));
		//version.getText();
		//version.click();
	
		ExtentTest test7=extent.createTest("TC-007- Add Bovine details");
	

		//Thread.sleep(2000);
		clickonElement(Pappom.get_Instance_addbovine().getAddbovine());
		implicitwait(3000,TimeUnit.SECONDS);
		inputonElement(Pappom.get_Instance_addbovine().getFphno(),prop.getProperty("Farmephno"));
		driver.hideKeyboard();
		clickonElement(Pappom.get_Instance_addbovine().getwhatsappcheckbox());
		inputonElement(Pappom.get_Instance_addbovine().getwhatsappno(),prop.getProperty("Whatsappno"));
		implicitwait(3000,TimeUnit.SECONDS);
		ExtentTest test8=extent.createTest("TC-008- Farmer details");
		clickonElement(Pappom.get_Instance_addbovine().getselect());
		implicitwait(3000,TimeUnit.SECONDS);
		clickonElement(Pappom.get_Instance_addbovine().getselectlang());
		implicitwait(3000,TimeUnit.SECONDS);
	
		inputonElement(Pappom.get_Instance_addbovine().getfarmername(),prop.getProperty("Farmername"));
		inputonElement(Pappom.get_Instance_addbovine().getvillagename(),prop.getProperty("Villagename"));
		clickonElement(Pappom.get_Instance_addbovine().getnext1());
		log.info("Sucessfully entered Farmer details");
		extent.flush();
		
		ExtentTest test9=extent.createTest("TC-008- Bovinedetails screen");

		//cow cow
		clickonElement(Pappom.get_Instance_addbovine().getclick1());
		clickonElement(Pappom.get_Instance_addbovine().getselectc1());
		implicitwait(3000,TimeUnit.SECONDS);
		
		clickonElement(Pappom.get_Instance_addbovine().getselectc2());
		clickonElement(Pappom.get_Instance_addbovine().gets3());

}
}