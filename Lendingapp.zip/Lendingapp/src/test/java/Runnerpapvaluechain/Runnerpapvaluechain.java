package Runnerpapvaluechain;

import org.testng.annotations.Test;

import src.test.java.Papvaluechain;

public class Runnerpapvaluechain {

	@Test
	public void testcase() throws Throwable  {

	
		
		Papvaluechainscript mobileapp =new  Papvaluechainscript();
		mobileapp.homescreen();
		mobileapp.Usersetting();
		mobileapp.Addbovine();
		
		mobileapp.Lactationdetails();
		
		mobileapp.feeddetails();
		mobileapp.preventivecaredetails();
		
		mobileapp.farmerquestion();
		mobileapp.photoscreen();
		mobileapp.Assessmentscreen();
		
		
	}
}
