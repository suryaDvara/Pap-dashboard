package Runnerpapvaluechain;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Pappom.Baseclass;
import Pappom.Papmanager;
import io.appium.java_client.AppiumBy;

public class Papvaluechainscript extends Baseclass{


	@SuppressWarnings("unused")
	ExtentSparkReporter reporter = new ExtentSparkReporter("./ReportPAPapp.html");
	ExtentReports extent = new ExtentReports();	
	Papmanager Pappom=new Papmanager(driver);
//	driver.startRecordingScreen();
@Test	
public void homescreen() throws FileNotFoundException, IOException, Throwable   {
	extent.attachReporter(reporter);
	ExtentTest test= extent.createTest("TC-PAP-VALUECHAINAPP");
	test.assignAuthor("Surya");
	test.assignCategory("End to End Teting");
	extent.flush();
   

	Logger  log=Logger.getLogger(Papvaluechainscript.class);
	PropertyConfigurator.configure("Log4j.properties");
	Properties prop = new Properties();
    prop.load(new FileInputStream("./Papapp.properties"));

    ExtentTest test1=extent.createTest("TC-001-HOME SCREEN");

    Thread.sleep(1000);
    inputonElement(Pappom.get_Instance_phno().getPhoneno(),prop.getProperty("phoneno"));
    driver.hideKeyboard();
    clickonElement(Pappom.get_Instance_phno().getPrivacypolicy());
    clickonElement(Pappom.get_Instance_phno().getAcceptpp());
    
	
    //Partner
    clickonElement(Pappom.get_Instance_phno().getContinuep());
    clickonElement(Pappom.get_Instance_phno().getok());
	
    //Verification
    implicitwait(3000,TimeUnit.SECONDS);
    driver.hideKeyboard();
    inputonElement(Pappom.get_Instance_phno().getOtpverify(),prop.getProperty("OTP"));
    //implicitwait(1000,TimeUnit.SECONDS);

    clickonElement(Pappom.get_Instance_phno().getVerify());
    log.info("Login Successfully");
    extent.flush();

	}
public void Usersetting() throws FileNotFoundException, IOException, InterruptedException    {
		extent.attachReporter(reporter);
		ExtentTest test= extent.createTest("TC-PAP-VALUECHAINAPP");
		extent.flush();
	   
	
		Logger  log=Logger.getLogger(Papvaluechainscript.class);
		PropertyConfigurator.configure("Log4j.properties");
		Properties prop = new Properties();
	    prop.load(new FileInputStream("./Papapp.properties"));
	
		//Usersetting
    implicitwait(3000,TimeUnit.SECONDS);
    
    clickonElement(Pappom.get_Instance_usersetting().getUsersetting1());
    Thread.sleep(2000);
    clickonElement(Pappom.get_Instance_usersetting().getup());
//    clickonElement(Pappom.get_Instance_usersetting().getusedit());
    clickonElement(Pappom.get_Instance_usersetting().getUsername());
    inputonElement(Pappom.get_Instance_usersetting().getUsername(),prop.getProperty("Username"));
    inputonElement(Pappom.get_Instance_usersetting().getOrgs(),prop.getProperty("Org"));
    clickonElement(Pappom.get_Instance_usersetting().getUpdetails());
    log.info("Userprofile");
    //langtamil
    extent.flush();
    ExtentTest test3=extent.createTest("TC-003- ALL LANGUAGE");
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_usersetting().getus1());
    Thread.sleep(2000);
    clickonElement(Pappom.get_Instance_usersetting().gettamil());
    clickonElement(Pappom.get_Instance_usersetting().gettr1());
    clickonElement(Pappom.get_Instance_usersetting().gettok2());
    log.info("Tamil");
    //lang guja/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView
    extent.flush();
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_usersetting().getus2());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_usersetting().getgujarathi());
    clickonElement(Pappom.get_Instance_usersetting().getg1());
    clickonElement(Pappom.get_Instance_usersetting().getgok2());
    log.info("Hindi");
    //Hindi
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_usersetting().getus4());
    implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_usersetting().getkannada());
	clickonElement(Pappom.get_Instance_usersetting().getK1());
	clickonElement(Pappom.get_Instance_usersetting().getKok2());
	log.info("Marathi");
	//Marathi
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_usersetting().getus5());
	Thread.sleep(2000);
	clickonElement(Pappom.get_Instance_usersetting().getMarathi());
	clickonElement(Pappom.get_Instance_usersetting().getm1());
	clickonElement(Pappom.get_Instance_usersetting().getmok2());
	log.info("Telugu");
	//Telugu
	Thread.sleep(2000);
	
	clickonElement(Pappom.get_Instance_usersetting().getUs6());
	Thread.sleep(2000);
	clickonElement(Pappom.get_Instance_usersetting().gettelugu());
	clickonElement(Pappom.get_Instance_usersetting().gettelugu1());
	clickonElement(Pappom.get_Instance_usersetting().gettelok2());
	log.info("English");
	//English
	implicitwait(3000,TimeUnit.SECONDS);
	 
	clickonElement(Pappom.get_Instance_usersetting().getus7());
	Thread.sleep(2000);
	clickonElement(Pappom.get_Instance_usersetting().getEnglish());
	clickonElement(Pappom.get_Instance_usersetting().getEok2());
	clickonElement(Pappom.get_Instance_usersetting().getEngok2());
	log.info("Refresh");
	//Refresh
    
	ExtentTest test4=extent.createTest("TC-004- USER SETTING -REFRESH");

	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_usersetting().getus8());
	 implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_usersetting().getrefresh());
	log.info("Customer care");
	extent.flush();
	ExtentTest test5=extent.createTest("TC-005- USER SETTING -customercare");

	//customer
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_usersetting().getcs());
	Thread.sleep(2000);
	clickonElement(Pappom.get_Instance_usersetting().getcs1());
	Thread.sleep(2000);
	clickonElement(Pappom.get_Instance_usersetting().getclose());
	log.info("Version 22.09.11");
	extent.flush();
	ExtentTest test6=extent.createTest("TC-006- USER SETTING -Version");

	//version
	 implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_usersetting().getv1());
    implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_usersetting().getVersion());
	extent.flush();
	//WebElement version= driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[7]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView"));
	//version.getText();
	//version.click();

	}
	
public void Addbovine() throws FileNotFoundException, Throwable {
		extent.attachReporter(reporter);
		ExtentTest test= extent.createTest("TC-PAP-VALUECHAINAPP");
		extent.flush();
	   
	
		Logger  log=Logger.getLogger(Papvaluechainscript.class);
		PropertyConfigurator.configure("Log4j.properties");
		Properties prop = new Properties();
	    prop.load(new FileInputStream("./Papapp.properties"));
		
	
	ExtentTest test7=extent.createTest("TC-007- Add Bovine details");


	//Thread.sleep(2000);
	clickonElement(Pappom.get_Instance_addbovine().getAddbovine());
	implicitwait(3000,TimeUnit.SECONDS);
	inputonElement(Pappom.get_Instance_addbovine().getFphno(),prop.getProperty("Farmephno"));
	driver.hideKeyboard();
	clickonElement(Pappom.get_Instance_addbovine().getwhatsappcheckbox());
	inputonElement(Pappom.get_Instance_addbovine().getwhatsappno(),prop.getProperty("Whatsappno"));
	implicitwait(3000,TimeUnit.SECONDS);
	ExtentTest test8=extent.createTest("TC-008- Farmer details");
	clickonElement(Pappom.get_Instance_addbovine().getselect());
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getselectlang());
	implicitwait(3000,TimeUnit.SECONDS);

	inputonElement(Pappom.get_Instance_addbovine().getfarmername(),prop.getProperty("Farmername"));
	inputonElement(Pappom.get_Instance_addbovine().getvillagename(),prop.getProperty("Villagename"));
	clickonElement(Pappom.get_Instance_addbovine().getnext1());
	log.info("Sucessfully entered Farmer details");
	extent.flush();
	
	ExtentTest test9=extent.createTest("TC-008- Bovinedetails screen");

	//cow cow
	clickonElement(Pappom.get_Instance_addbovine().getclick1());
	clickonElement(Pappom.get_Instance_addbovine().getselectc1());
	implicitwait(3000,TimeUnit.SECONDS);
	
	clickonElement(Pappom.get_Instance_addbovine().getselectc2());
	clickonElement(Pappom.get_Instance_addbovine().gets3());
	implicitwait(3000,TimeUnit.SECONDS);
	
			
	//barcode.click();
	inputonElement(Pappom.get_Instance_addbovine().getpetname(),prop.getProperty("Cowname"));
    //Lastcalving
	implicitwait(3000,TimeUnit.SECONDS);
	inputonElement(Pappom.get_Instance_addbovine().getdslcalving(),prop.getProperty("Lastcalving"));
	
	//pregnant
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getpregstatus());
	implicitwait(3000,TimeUnit.SECONDS);

	clickonElement(Pappom.get_Instance_addbovine().getpregc1());
	//noof pregnant
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getNopreg());
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getpregc2());
	
	//Milking status
	
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getmilkingstatus());
	implicitwait(1000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getmilkingclick());
	driver.findElement(AppiumBy.androidUIAutomator( "new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(1)"));
	
	//lactation
	implicitwait(3000,TimeUnit.SECONDS);
	inputonElement(Pappom.get_Instance_addbovine().getLact(),prop.getProperty("Lactation"));

	//onboarding
	
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getOnboardings());
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getOnbclick());
	//assessment
	clickonElement(Pappom.get_Instance_addbovine().getAssessment());
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getAssessselect());
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getNext2());
	log.info("Succesfully Entered bovine details");
	extent.flush();
	}

public void Notpregnant() {
	
	
}

public void Lactationdetails() throws FileNotFoundException, IOException {
		extent.attachReporter(reporter);
		ExtentTest test= extent.createTest("TC-PAP-VALUECHAINAPP");
		extent.flush();
		Logger  log=Logger.getLogger(Papvaluechainscript.class);
		PropertyConfigurator.configure("Log4j.properties");
		Properties prop = new Properties();
	    prop.load(new FileInputStream("./Papapp.properties"));
		
	ExtentTest test10=extent.createTest("TC-010- Lactation Details Screen");{
	
		//Lactation details
	inputonElement(Pappom.get_Instance_lactation().getCurrentmy(),prop.getProperty("Currentmilkyield"));
	inputonElement(Pappom.get_Instance_lactation().getPeakmy(),prop.getProperty("Peakmilkyield"));
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_lactation().getNext3());
	log.info("succesfully entered the Lactation details");
	}extent.flush();
	}
	
public void feeddetails() throws FileNotFoundException, Throwable {
		extent.attachReporter(reporter);
		ExtentTest test= extent.createTest("TC-PAP-VALUECHAINAPP");
		extent.flush();
	   
	
		Logger  log=Logger.getLogger(Papvaluechainscript.class);
		PropertyConfigurator.configure("Log4j.properties");
		Properties prop = new Properties();
	    prop.load(new FileInputStream("./Pap.properties"));
	
	ExtentTest test11=extent.createTest("TC-011- Feed details screen");{
	//Feed details
	implicitwait(3000,TimeUnit.SECONDS);
	inputonElement(Pappom.get_Instance_feeddetails().getGreenfodder(),prop.getProperty("Gf"));
	inputonElement(Pappom.get_Instance_feeddetails().getDryfodder(),prop.getProperty("Df"));
	inputonElement(Pappom.get_Instance_feeddetails().getConcentratedfodder(),prop.getProperty("Cf"));
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_feeddetails().getNext4());
	log.info("Entered feed details");
	extent.flush();
	}
	ExtentTest test12=extent.createTest("TC-012- Local Feed Ingredients screen");{
	//Local Feed ingredients
	implicitwait(3000,TimeUnit.SECONDS);
	inputonElement(Pappom.get_Instance_localfeed().getLocalfeed1(),prop.getProperty("Localfeed"));
	implicitwait(3000,TimeUnit.SECONDS);
	inputonElement(Pappom.get_Instance_localfeed().getQuantity1(),prop.getProperty("Quantity1"));
	clickonElement(Pappom.get_Instance_localfeed().getNext5());
	log.info("Entered Local feed ingredents");
	extent.flush();
	}
	}
	
public void preventivecaredetails() throws InterruptedException, FileNotFoundException, Throwable {
		extent.attachReporter(reporter);
		ExtentTest test= extent.createTest("TC-PAP-VALUECHAINAPP");
		extent.flush();
	   
	
		Logger  log=Logger.getLogger(Papvaluechainscript.class);
		PropertyConfigurator.configure("Log4j.properties");
		Properties prop = new Properties();
	    prop.load(new FileInputStream("./Papapp.properties"));
	
		ExtentTest test13=extent.createTest("TC-013- Preventive care details screen");{
	//preventive care details
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_preventivecare().getDeworming());
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_preventivecare().getDewormingclick());
	

	//dewormingdate
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_preventivecare().getDewormingDateselect());
	implicitwait(2000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_preventivecare().getDewormingcal());
	clickonElement(Pappom.get_Instance_preventivecare().getDewormingok());
	//vaccine
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_preventivecare().getvaccines());
	clickonElement(Pappom.get_Instance_preventivecare().getvaccineclick());
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_preventivecare().getVname());
	clickonElement(Pappom.get_Instance_preventivecare().getVnameselect());
	Thread.sleep(2000);
	clickonElement(Pappom.get_Instance_preventivecare().getVaccinecal());
	Thread.sleep(2000);
	clickonElement(Pappom.get_Instance_preventivecare().getVaccinecdate());
	clickonElement(Pappom.get_Instance_preventivecare().getvaccineok());
	//vetexpenses
	implicitwait(3000,TimeUnit.SECONDS);
	inputonElement(Pappom.get_Instance_preventivecare().getVetexp(),prop.getProperty("Vetexpense"));
	inputonElement(Pappom.get_Instance_preventivecare().getMajordiseases(),prop.getProperty("Majordiseases"));
	driver.findElement(AppiumBy.androidUIAutomator( "new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(1)"));
	implicitwait(1000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_preventivecare().getNext6());
	log.info("preventive care details");
	extent.flush();
	}
	}
	//ExtentTest test14=extent.createTest("TC-014- Farmer question screen");
	//Farmerques
public void farmerquestion() throws FileNotFoundException, Throwable {
	extent.attachReporter(reporter);
	ExtentTest test= extent.createTest("TC-PAP-VALUECHAINAPP");
	extent.flush();
   

	Logger  log=Logger.getLogger(Papvaluechainscript.class);
	PropertyConfigurator.configure("Log4j.properties");
	Properties prop = new Properties();
    prop.load(new FileInputStream("./Papapp.properties"));

	ExtentTest test15=extent.createTest("TC-015- Farmer question screen");{

	implicitwait(2000,TimeUnit.SECONDS);
	inputonElement(Pappom.get_Instance_farmerques().getQuestion(),prop.getProperty("Question"));
	clickonElement(Pappom.get_Instance_farmerques().getNext7());
    log.info("successfully entered Farmer question");
    extent.flush();
	}
}

public void photoscreen() throws FileNotFoundException, Throwable {
	extent.attachReporter(reporter);
	ExtentTest test= extent.createTest("TC-PAP-VALUECHAINAPP");
	extent.flush();
   

	Logger  log=Logger.getLogger(Papvaluechainscript.class);
	PropertyConfigurator.configure("Log4j.properties");
	Properties prop = new Properties();
    prop.load(new FileInputStream("./Papapp.properties"));

	ExtentTest test16=extent.createTest("TC-016- Photo1 screen");{
    //photo
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_photoscreen().getFullviewclick());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_photoscreen().getPhbt1());
    try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
    clickonElement(Pappom.get_Instance_photoscreen().getCrop1());
    extent.flush();
	}
    ExtentTest test17=extent.createTest("TC-017- Photo2 screen");{

     //photo2
    clickonElement(Pappom.get_Instance_photoscreen().getMuzzle());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_photoscreen().getContinue1());
    implicitwait(2000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_photoscreen().getAuto());
    Thread.sleep(4000);
    extent.flush();
    }
	ExtentTest test18=extent.createTest("TC-018- Photo3 screen");{

    //photo3
    clickonElement(Pappom.get_Instance_photoscreen().getLeftside());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_photoscreen().getCam2());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_photoscreen().getCrop2());
	driver.findElement(AppiumBy.androidUIAutomator( "new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(1)"));
	extent.flush();
	}
	ExtentTest test19=extent.createTest("TC-019- Photo4 leftsideudder");{

    //Leftsideudder
    clickonElement(Pappom.get_Instance_photoscreen().getLeftsideudder());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_photoscreen().getCam3());
    implicitwait(1000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_photoscreen().getCrop3());
    extent.flush();}
	
    ExtentTest test20=extent.createTest("TC-020- Photo5 Backside");{

    //backside
    clickonElement(Pappom.get_Instance_photoscreen().getbackside());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_photoscreen().getCam4());
    Thread.sleep(1000);
    clickonElement(Pappom.get_Instance_photoscreen().getCrop4());
	//driver.findElement(AppiumBy.androidUIAutomator( "new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(1)"));
    extent.flush();}
    
    ExtentTest test21=extent.createTest("TC-021- Photo6 Rightside");{

    //Rightside
    clickonElement(Pappom.get_Instance_photoscreen().getrightside());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_photoscreen().getCam5());
    implicitwait(1000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_photoscreen().getCrop5());
    extent.flush();}
    //rightsideudder
    ExtentTest test22=extent.createTest("TC-022- Photo7 Rightside");{

    clickonElement(Pappom.get_Instance_photoscreen().getrightideudder());
    implicitwait(2000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_photoscreen().getCam6());
    implicitwait(1000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_photoscreen().getCrop6());
    extent.flush();}
    //
    ExtentTest test23=extent.createTest("TC-023- Photo8 Rightside");{

    clickonElement(Pappom.get_Instance_photoscreen().getAbnormal());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_photoscreen().getCam7()); 		
    implicitwait(1000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_photoscreen().getCrop7());
    extent.flush();}
    ExtentTest test24=extent.createTest("TC-024 Edit Bovine details screen");{
    //edit
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_edit().getEdit());
    
    ExtentTest test25=extent.createTest("TC-025 Edit: "); 
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_edit().getYesbutton());
    
    ExtentTest test26=extent.createTest("TC-026 Edit:");
    implicitwait(2000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_edit().getBnext1());
    
    ExtentTest test27=extent.createTest("TC-027 Edit Bovine details screen");
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_edit().getLnext2());
    ExtentTest test28=extent.createTest("TC-028 Edit Bovine details screen");
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_edit().getNext3());
    ExtentTest test29=extent.createTest("TC-029 Edit Bovine details screen");
    
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_edit().getNext4());
    
    ExtentTest test30=extent.createTest("TC-030 Edit Bovine details screen");
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_edit().getNext5());
    
    ExtentTest test32=extent.createTest("TC-031 Edit Bovine details screen");
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_edit().getNext6());
    
    ExtentTest test33=extent.createTest("TC-032 Edit Bovine details screen");
    implicitwait(3000,TimeUnit.SECONDS);
	driver.findElement(AppiumBy.androidUIAutomator( "new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(1)"));

	   ExtentTest test34=extent.createTest("TC-034 Edit Bovine details screen");
	clickonElement(Pappom.get_Instance_edit().getSubmitt());
   
    clickonElement(Pappom.get_Instance_edit().getsubmityes());
    log.info("Edit");
    extent.flush();
    }
    //assessment
    //upload
    ExtentTest test35=extent.createTest("TC-035- upload screen");{

    clickonElement(Pappom.get_Instance_addbovine().getUpload());
    extent.flush();
    log.info("Upload");
    }
}

public void Assessmentscreen() throws InterruptedException, FileNotFoundException, IOException {
	extent.attachReporter(reporter);
	ExtentTest test= extent.createTest("TC-PAP-VALUECHAINAPP");
	extent.flush();
   

	Logger  log=Logger.getLogger(Papvaluechainscript.class);
	PropertyConfigurator.configure("Log4j.properties");
	Properties prop = new Properties();
    prop.load(new FileInputStream("./Papapp.properties"));

	ExtentTest test36=extent.createTest("TC-036- Assessment screen");{

    implicitwait(1000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getAssclick());
    inputonElement(Pappom.get_Instance_assessment().getAssfarmerno(),prop.getProperty("Assphno"));
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getFarmerassclick());
    clickonElement(Pappom.get_Instance_assessment().getPfarmerass1());
    clickonElement(Pappom.get_Instance_assessment().getYes());
    clickonElement(Pappom.get_Instance_assessment().getImplementyes());
    clickonElement(Pappom.get_Instance_assessment().getDewyes());
	driver.findElement(AppiumBy.androidUIAutomator( "new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(1)"));
	implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getVaccyes());
    clickonElement(Pappom.get_Instance_assessment().getMmyes());
   
    clickonElement(Pappom.get_Instance_assessment().getFeedcost());
    clickonElement(Pappom.get_Instance_assessment().getMilkprice());
	driver.findElement(AppiumBy.androidUIAutomator( "new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(1)"));
    inputonElement(Pappom.get_Instance_assessment().getAmount(),prop.getProperty("Amt"));
    inputonElement(Pappom.get_Instance_assessment().getLiter(),prop.getProperty("Liter"));
    clickonElement(Pappom.get_Instance_assessment().getAssnext());
    log.info("Impact Assessment");
    extent.flush();}
    //bovine
    ExtentTest test37=extent.createTest("TC-037- Assessment screen");{

    implicitwait(3000,TimeUnit.SECONDS);
  
    clickonElement(Pappom.get_Instance_assessment().getBtypec1());
    clickonElement(Pappom.get_Instance_assessment().getSelecttype());
    clickonElement(Pappom.get_Instance_assessment().getBuffalotype1());
    clickonElement(Pappom.get_Instance_assessment().getBtypeselect());
    inputonElement(Pappom.get_Instance_assessment().getPetname(),prop.getProperty("Asscowname"));
    inputonElement(Pappom.get_Instance_assessment().getLastcalving(),prop.getProperty("Lastcalvingass"));
    clickonElement(Pappom.get_Instance_assessment().getPregselect());
    clickonElement(Pappom.get_Instance_assessment().getPregstatus());
    
    
    clickonElement(Pappom.get_Instance_assessment().getAssmilklingstatus());
    clickonElement(Pappom.get_Instance_assessment().getAssmilking());
    inputonElement(Pappom.get_Instance_assessment().getLactation(),prop.getProperty("Asslactation"));
    driver.findElement(AppiumBy.androidUIAutomator( "new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(1)"));

    clickonElement(Pappom.get_Instance_assessment().getOnboardingselect());
    clickonElement(Pappom.get_Instance_assessment().getOnboardtype());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getAssesstype());
    clickonElement(Pappom.get_Instance_assessment().getAssessselect());
    clickonElement(Pappom.get_Instance_assessment().getAsnext());
    log.info("Assessment bovine details");
    
    extent.flush();}
    
    ExtentTest test38=extent.createTest("TC-038- Assessment lactation details screen");{

    //lacation
    implicitwait(3000,TimeUnit.SECONDS);
    inputonElement(Pappom.get_Instance_assessment().getPeakmilkyield(),prop.getProperty("Pmy"));
    implicitwait(2000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getLacnext());
    log.info("Assessment Lactation");
    extent.flush();}
    
    ExtentTest test39=extent.createTest("TC-039- Assessment Breeding details screen");{

    //breeding
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getBdpregtype());
    clickonElement(Pappom.get_Instance_assessment().getBdselect());
    inputonElement(Pappom.get_Instance_assessment().getDss(),prop.getProperty("Dss"));
    driver.hideKeyboard();
    clickonElement(Pappom.get_Instance_assessment().getNofservice());
    clickonElement(Pappom.get_Instance_assessment().getSelectservice());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getUptype());
    clickonElement(Pappom.get_Instance_assessment().getUpselect());
    clickonElement(Pappom.get_Instance_assessment().getUttype());
    clickonElement(Pappom.get_Instance_assessment().getUtselect());
    implicitwait(1000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getBdnext());
    log.info("Assessment Breeding details");
    extent.flush();}
    
    ExtentTest test40=extent.createTest("TC-040- Assessment lactation details screen");{

    //gf
    implicitwait(3000,TimeUnit.SECONDS);
    inputonElement(Pappom.get_Instance_assessment().getGf(),prop.getProperty("AGf"));
    inputonElement(Pappom.get_Instance_assessment().getDf(),prop.getProperty("ADf"));
    driver.hideKeyboard();
    inputonElement(Pappom.get_Instance_assessment().getCf(),prop.getProperty("ACf"));
    clickonElement(Pappom.get_Instance_assessment().getFdsnext());
    implicitwait(3000,TimeUnit.SECONDS);
    log.info("Assessment Feed details");
    //
    extent.flush();}
    clickonElement(Pappom.get_Instance_assessment().getLocalfeednext());
    
    ExtentTest test41=extent.createTest("TC-041- Assessment Preventive details screen");{

    //preventivecare
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getPdcstatus());
    clickonElement(Pappom.get_Instance_assessment().getDdyes());
    clickonElement(Pappom.get_Instance_assessment().getVstatus());
    clickonElement(Pappom.get_Instance_assessment().getVyes());
    inputonElement(Pappom.get_Instance_assessment().getVexpense(),prop.getProperty("Avetexpense"));
    inputonElement(Pappom.get_Instance_assessment().getMajordisease(),prop.getProperty("Amajordiseases"));
    clickonElement(Pappom.get_Instance_assessment().getPcnext());
    log.info("Assessment Preventive care details");
    extent.flush();}
    
    ExtentTest test42=extent.createTest("TC-042- Assessment Farmer question screen");{

    //farmerquestion
    implicitwait(3000,TimeUnit.SECONDS);
    inputonElement(Pappom.get_Instance_assessment().getFarmerquestion(),prop.getProperty("AFarmerquestion"));
    clickonElement(Pappom.get_Instance_assessment().getFarmerques());
    log.info("Assessment Farmer question");
    extent.flush();}
    
    ExtentTest test43=extent.createTest("TC-043- Assessment Photo screen");{

    //photo
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getFullsideview());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getAsscam1());
    clickonElement(Pappom.get_Instance_assessment().getAsscrop1());
    extent.flush();}
    
    ExtentTest test44=extent.createTest("TC-044- Assessment Photo screen");{

    //
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getAssmuzzle());
    clickonElement(Pappom.get_Instance_assessment().getAsscontinue());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getAssauto());
    driver.findElement(AppiumBy.androidUIAutomator( "new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(1)"));
    extent.flush();}
    
    ExtentTest test45=extent.createTest("TC-045- Assessment Photo screen");{

    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getLeftside());
    clickonElement(Pappom.get_Instance_assessment().getAsscam2());
    implicitwait(2000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getAsscrop2());
    extent.flush();}
    
    ExtentTest test46=extent.createTest("TC-046- Assessment Photo screen");{

    //
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getLsudder());
    clickonElement(Pappom.get_Instance_assessment().getAsscam3());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getAsscrop3());
    driver.findElement(AppiumBy.androidUIAutomator( "new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(1)"));
    extent.flush();}
    
    ExtentTest test47=extent.createTest("TC-047- Assessment Photo screen");{

    //
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getBsideview());
    
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getAsscam4());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getAsscrop4());
    extent.flush();
    }
    ExtentTest test48=extent.createTest("TC-048- Assessment Photo screen");{

    //
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getRsidetail());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getAsscam5());
    clickonElement(Pappom.get_Instance_assessment().getAsscrop5());
    driver.findElement(AppiumBy.androidUIAutomator( "new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(1)"));
    extent.flush();}
    
    ExtentTest test49=extent.createTest("TC-049- Assessment Rightside Photo");{

    //
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getRightsideu());
    clickonElement(Pappom.get_Instance_assessment().getAsscam6());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getAsscrop6());
    
    extent.flush();}
    
    ExtentTest test50=extent.createTest("TC-050- Assessment Abnormalitites Photo");{

    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getAbnor());
    clickonElement(Pappom.get_Instance_assessment().getAbnormcam7());
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getAsscrop7());
    driver.findElement(AppiumBy.androidUIAutomator( "new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(1)"));
    extent.flush();
    }
    ExtentTest test51=extent.createTest("TC-051- Assessment Upload Photo");{

    //
    implicitwait(3000,TimeUnit.SECONDS);
    clickonElement(Pappom.get_Instance_assessment().getAsssubmit());
    clickonElement(Pappom.get_Instance_assessment().getAsssubmityes());
    implicitwait(5000,TimeUnit.SECONDS); 
    clickonElement(Pappom.get_Instance_assessment().getAssuplaod()); 
    log.info("Assessment photo");
    extent.flush();}
    
    ExtentTest test52=extent.createTest("TC-052- Assessment Logout");{
    //Logout
	Thread.sleep(2000);
	clickonElement(Pappom.get_Instance_usersetting().getLogout());
	Thread.sleep(2000);
	clickonElement(Pappom.get_Instance_usersetting().getLogoutbt());
	Thread.sleep(2000);

	clickonElement(Pappom.get_Instance_usersetting().getbutton());
	log.info("Logout");
	extent.flush();    	
    }
}	
	}



    
	
