package Runnerpapvaluechain;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import Pappom.Baseclass;
import Pappom.Papmanager;

public class Farmerdetails extends Baseclass{
	@Test
	public void testcase() throws Throwable {
	Papmanager Pappom=new Papmanager(driver);

	 Properties prop = new Properties();
		prop.load(new FileInputStream("./Papapp.properties"));
		
		
		Logger  log=Logger.getLogger(Runnerpapmobileapp.class);
		PropertyConfigurator.configure("Log4j.properties");
					
	

	ExtentReports extent=new ExtentReports();

	
	
	ExtentTest test7=extent.createTest("TC-007- Add Bovine details");
	

	//Thread.sleep(2000);
	clickonElement(Pappom.get_Instance_addbovine().getAddbovine());
	implicitwait(3000,TimeUnit.SECONDS);
	inputonElement(Pappom.get_Instance_addbovine().getFphno(),prop.getProperty("Farmephno"));
	driver.hideKeyboard();
	clickonElement(Pappom.get_Instance_addbovine().getwhatsappcheckbox());
	inputonElement(Pappom.get_Instance_addbovine().getwhatsappno(),prop.getProperty("Whatsappno"));
	implicitwait(3000,TimeUnit.SECONDS);
	ExtentTest test8=extent.createTest("TC-008- Farmer details");
	clickonElement(Pappom.get_Instance_addbovine().getselect());
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getselectlang());
	implicitwait(3000,TimeUnit.SECONDS);

	inputonElement(Pappom.get_Instance_addbovine().getfarmername(),prop.getProperty("Farmername"));
	inputonElement(Pappom.get_Instance_addbovine().getvillagename(),prop.getProperty("Villagename"));
	clickonElement(Pappom.get_Instance_addbovine().getnext1());
	log.info("Sucessfully entered Farmer details");
	extent.flush();
	}
}
