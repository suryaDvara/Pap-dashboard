package Runnerpapvaluechain;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import Pappom.Baseclass;
import Pappom.Papmanager;
import io.appium.java_client.AppiumBy;

public class Bovinedetails extends Baseclass{
	@Test
	public void cowcow() throws Throwable {
	Papmanager Pappom=new Papmanager(driver);

	 Properties prop = new Properties();
		prop.load(new FileInputStream("./Papapp.properties"));
		
		
		Logger  log=Logger.getLogger(Runnerpapmobileapp.class);
		PropertyConfigurator.configure("Log4j.properties");
					
	

	ExtentReports extent=new ExtentReports();
	ExtentTest test9=extent.createTest("TC-008- Bovinedetails screen");

	//cow cow
	clickonElement(Pappom.get_Instance_addbovine().getclick1());
	clickonElement(Pappom.get_Instance_addbovine().getselectc1());
	implicitwait(3000,TimeUnit.SECONDS);
	
	clickonElement(Pappom.get_Instance_addbovine().getselectc2());
	clickonElement(Pappom.get_Instance_addbovine().gets3());
	implicitwait(3000,TimeUnit.SECONDS);
	
			
	//barcode.click();
	inputonElement(Pappom.get_Instance_addbovine().getpetname(),prop.getProperty("Cowname"));
    //Lastcalving
	implicitwait(3000,TimeUnit.SECONDS);
	inputonElement(Pappom.get_Instance_addbovine().getdslcalving(),prop.getProperty("Lastcalving"));
	
	//pregnant
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getpregstatus());
	implicitwait(3000,TimeUnit.SECONDS);

	clickonElement(Pappom.get_Instance_addbovine().getpregc1());
	//noof pregnant
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getNopreg());
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getpregc2());
	
	//Milking status
	
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getmilkingstatus());
	implicitwait(1000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getmilkingclick());
	driver.findElement(AppiumBy.androidUIAutomator( "new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(1)"));
	
	//lactation
	implicitwait(3000,TimeUnit.SECONDS);
	inputonElement(Pappom.get_Instance_addbovine().getLact(),prop.getProperty("Lactation"));

	//onboarding
	
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getOnboardings());
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getOnbclick());
	//assessment
	clickonElement(Pappom.get_Instance_addbovine().getAssessment());
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getAssessselect());
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_addbovine().getNext2());
	log.info("Succesfully Entered bovine details");
	extent.flush();
	
	
	}
}
