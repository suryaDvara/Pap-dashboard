package Runnerpapvaluechain;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import Pappom.Baseclass;
import Pappom.Papmanager;

public class Runnerpapmobileapp extends Baseclass {
  	@Test
	public void testcase() throws Throwable  {
		
	
		Homescreen home=new Homescreen();
		home.testcase();
		
		Farmerdetails faremerdetail=new Farmerdetails();
		faremerdetail.testcase();
		
		Bovinedetails Bovine=new Bovinedetails();
		Bovine.cowcow();
		
		Feedingdetails feed= new Feedingdetails();
		feed.feeddetail();
		feed.Preventivecaredetailsscreen();
		
		
	
		
	
}
}