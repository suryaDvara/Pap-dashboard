package Runnerpapvaluechain;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import Pappom.Baseclass;
import Pappom.Papmanager;
import io.appium.java_client.AppiumBy;

public class Feedingdetails extends Baseclass  {
	Papmanager Pappom=new Papmanager(driver);
	
	
	
	
	@Test
	public void feeddetail() throws Throwable, IOException  {
		   Papmanager Pappom=new Papmanager(driver);

		    Properties prop = new Properties();
			prop.load(new FileInputStream("./Papapp.properties"));
			
			
			Logger  log=Logger.getLogger(Runnerpapmobileapp.class);
			PropertyConfigurator.configure("Log4j.properties");
						
		

		ExtentReports extent=new ExtentReports();


	
	ExtentTest test11=extent.createTest("TC-011- Feed details screen");{
		//Feed details
		implicitwait(3000,TimeUnit.SECONDS);
		inputonElement(Pappom.get_Instance_feeddetails().getGreenfodder(),prop.getProperty("Gf"));
		inputonElement(Pappom.get_Instance_feeddetails().getDryfodder(),prop.getProperty("Df"));
		inputonElement(Pappom.get_Instance_feeddetails().getConcentratedfodder(),prop.getProperty("Cf"));
		implicitwait(3000,TimeUnit.SECONDS);
		clickonElement(Pappom.get_Instance_feeddetails().getNext4());
		log.info("Entered feed details");
		extent.flush();
		}
		
//	public void LocalFeedingredients(){
	    
	
	     ExtentTest test12=extent.createTest("TC-012- Local Feed Ingredients screen");{
		//Local Feed ingredients
		implicitwait(3000,TimeUnit.SECONDS);
		inputonElement(Pappom.get_Instance_localfeed().getLocalfeed1(),prop.getProperty("Localfeed"));
		implicitwait(3000,TimeUnit.SECONDS);
		inputonElement(Pappom.get_Instance_localfeed().getQuantity1(),prop.getProperty("Quantity1"));
		clickonElement(Pappom.get_Instance_localfeed().getNext5());
		log.info("Entered Local feed ingredents");
		extent.flush();
		}
	}
		
public void Preventivecaredetailsscreen() throws FileNotFoundException, IOException, Throwable  {

    Properties prop = new Properties();
	prop.load(new FileInputStream("./Papapp.properties"));
	
	
	Logger  log=Logger.getLogger(Runnerpapmobileapp.class);
	PropertyConfigurator.configure("Log4j.properties");
				
	
	ExtentReports extent=new ExtentReports();	
	ExtentTest test13=extent.createTest("TC-013- Preventive care details screen");{
		//preventive care details
		implicitwait(3000,TimeUnit.SECONDS);
		clickonElement(Pappom.get_Instance_preventivecare().getDeworming());
		implicitwait(3000,TimeUnit.SECONDS);
		clickonElement(Pappom.get_Instance_preventivecare().getDewormingclick());
		
		
		//dewormingdate
	    implicitwait(3000,TimeUnit.SECONDS);
		clickonElement(Pappom.get_Instance_preventivecare().getDewormingDateselect());
		implicitwait(2000,TimeUnit.SECONDS);
		clickonElement(Pappom.get_Instance_preventivecare().getDewormingcal());
		clickonElement(Pappom.get_Instance_preventivecare().getDewormingok());
		//vaccine
		implicitwait(3000,TimeUnit.SECONDS);
		clickonElement(Pappom.get_Instance_preventivecare().getvaccines());
		clickonElement(Pappom.get_Instance_preventivecare().getvaccineclick());
		implicitwait(3000,TimeUnit.SECONDS);
		clickonElement(Pappom.get_Instance_preventivecare().getVname());
		clickonElement(Pappom.get_Instance_preventivecare().getVnameselect());
		Thread.sleep(2000);
		clickonElement(Pappom.get_Instance_preventivecare().getVaccinecal());
		Thread.sleep(2000);
		clickonElement(Pappom.get_Instance_preventivecare().getVaccinecdate());
		clickonElement(Pappom.get_Instance_preventivecare().getvaccineok());
		//vetexpenses
		implicitwait(3000,TimeUnit.SECONDS);
		
		
		inputonElement(Pappom.get_Instance_preventivecare().getVetexp(),prop.getProperty("Vetexpense"));
		inputonElement(Pappom.get_Instance_preventivecare().getMajordiseases(),prop.getProperty("Majordiseases"));

		driver.findElement(AppiumBy.androidUIAutomator( "new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(1)"));
		implicitwait(1000,TimeUnit.SECONDS);
		clickonElement(Pappom.get_Instance_preventivecare().getNext6());
		log.info("preventive care details");
		extent.flush();
		}
	
		//ExtentTest test14=extent.createTest("TC-014- Farmer question screen");
		//Farmerques
		ExtentTest test15=extent.createTest("TC-015- Farmer question screen");{

		implicitwait(2000,TimeUnit.SECONDS);
		inputonElement(Pappom.get_Instance_farmerques().getQuestion(),prop.getProperty("Question"));
		clickonElement(Pappom.get_Instance_farmerques().getNext7());
	    log.info("successfully entered Farmer question");
	    extent.flush();
		}
		ExtentTest test16=extent.createTest("TC-016- Photo1 screen");{
	    //photo
	    implicitwait(3000,TimeUnit.SECONDS);
	    clickonElement(Pappom.get_Instance_photoscreen().getFullviewclick());
	    implicitwait(3000,TimeUnit.SECONDS);
	    clickonElement(Pappom.get_Instance_photoscreen().getPhbt1());
	    Thread.sleep(1000);
	    
	    clickonElement(Pappom.get_Instance_photoscreen().getCrop1());
	    extent.flush();
		}
	    ExtentTest test17=extent.createTest("TC-017- Photo2 screen");{

	     //photo2
	    clickonElement(Pappom.get_Instance_photoscreen().getMuzzle());
	    implicitwait(3000,TimeUnit.SECONDS);
	    clickonElement(Pappom.get_Instance_photoscreen().getContinue1());
	    implicitwait(2000,TimeUnit.SECONDS);
	    clickonElement(Pappom.get_Instance_photoscreen().getAuto());
	    Thread.sleep(4000);
	    extent.flush();
	    }
	    
		ExtentTest test18=extent.createTest("TC-018- Photo3 screen");{

	    //photo3
	    clickonElement(Pappom.get_Instance_photoscreen().getLeftside());
	    implicitwait(3000,TimeUnit.SECONDS);
	    clickonElement(Pappom.get_Instance_photoscreen().getCam2());
	    implicitwait(3000,TimeUnit.SECONDS);
	    clickonElement(Pappom.get_Instance_photoscreen().getCrop2());
		driver.findElement(AppiumBy.androidUIAutomator( "new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(1)"));
		extent.flush();
		}
		ExtentTest test19=extent.createTest("TC-019- Photo4 leftsideudder");{

	    //Leftsideudder
	    clickonElement(Pappom.get_Instance_photoscreen().getLeftsideudder());
	    implicitwait(3000,TimeUnit.SECONDS);
	    clickonElement(Pappom.get_Instance_photoscreen().getCam3());
	    implicitwait(1000,TimeUnit.SECONDS);
	    clickonElement(Pappom.get_Instance_photoscreen().getCrop3());
	    extent.flush();}
		
	    ExtentTest test20=extent.createTest("TC-020- Photo5 Backside");{

	    //backside
	    clickonElement(Pappom.get_Instance_photoscreen().getbackside());
	    implicitwait(3000,TimeUnit.SECONDS);
	    clickonElement(Pappom.get_Instance_photoscreen().getCam4());
	    Thread.sleep(1000);
	    clickonElement(Pappom.get_Instance_photoscreen().getCrop4());
		//driver.findElement(AppiumBy.androidUIAutomator( "new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(1)"));
	    extent.flush();}
	    
	    ExtentTest test21=extent.createTest("TC-021- Photo6 Rightside");{

	    //Rightside
	    clickonElement(Pappom.get_Instance_photoscreen().getrightside());
	    implicitwait(3000,TimeUnit.SECONDS);
	    clickonElement(Pappom.get_Instance_photoscreen().getCam5());
	    implicitwait(1000,TimeUnit.SECONDS);
	    clickonElement(Pappom.get_Instance_photoscreen().getCrop5());
	    extent.flush();}
	    //rightsideudder
	    ExtentTest test22=extent.createTest("TC-022- Photo7 Rightside");{

	    clickonElement(Pappom.get_Instance_photoscreen().getrightideudder());
	    implicitwait(2000,TimeUnit.SECONDS);
	    clickonElement(Pappom.get_Instance_photoscreen().getCam6());
	    implicitwait(1000,TimeUnit.SECONDS);
	    clickonElement(Pappom.get_Instance_photoscreen().getCrop6());
	    extent.flush();}
	    //
	    ExtentTest test23=extent.createTest("TC-023- Photo8 Rightside");{

	    clickonElement(Pappom.get_Instance_photoscreen().getAbnormal());
	    implicitwait(3000,TimeUnit.SECONDS);
	    clickonElement(Pappom.get_Instance_photoscreen().getCam7()); 		
	    implicitwait(1000,TimeUnit.SECONDS);
	    clickonElement(Pappom.get_Instance_photoscreen().getCrop7());
	    extent.flush();}
	

		
	}


}

