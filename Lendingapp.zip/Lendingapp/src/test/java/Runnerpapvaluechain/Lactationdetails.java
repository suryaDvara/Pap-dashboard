package Runnerpapvaluechain;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import Pappom.Baseclass;
import Pappom.Papmanager;

public class Lactationdetails extends Baseclass {

	@Test
	public void lavtationdetails() throws Throwable, IOException {
		Papmanager Pappom=new Papmanager(driver);

		 Properties prop = new Properties();
			prop.load(new FileInputStream("./Papapp.properties"));
			
			
			Logger  log=Logger.getLogger(Runnerpapmobileapp.class);
			PropertyConfigurator.configure("Log4j.properties");
						
			ExtentReports extent=new ExtentReports();

	ExtentTest test10=extent.createTest("TC-010- Lactation Details Screen");{
		
		//Lactation details
	inputonElement(Pappom.get_Instance_lactation().getCurrentmy(),prop.getProperty("Currentmilkyield"));
	inputonElement(Pappom.get_Instance_lactation().getPeakmy(),prop.getProperty("Peakmilkyield"));
	implicitwait(3000,TimeUnit.SECONDS);
	clickonElement(Pappom.get_Instance_lactation().getNext3());
	log.info("succesfully entered the Lactation details");
	}extent.flush();
}
}